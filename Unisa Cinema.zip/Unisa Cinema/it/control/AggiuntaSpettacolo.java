package control;

import java.io.IOException;
import java.util.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.PromozioneBean;
import bean.SpettacoloBean;
import model.SpettacoloModelDM;

/**
 * Servlet implementation class AggiuntaSpettacoloSpettacolo
 */
@WebServlet(name = "AggiuntaSpettacoloSpettacolo", urlPatterns = "/aggiuntaSpettacolo")
public class AggiuntaSpettacolo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AggiuntaSpettacolo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		/*String action = request.getParameter("action");
		if(action == null){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}else if(action.equalsIgnoreCase("AggiuntaSpettacolo")){*/
		
		String dataSpettacolo = request.getParameter("data");
		if((dataSpettacolo == null)){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		Date data = null;
		try{
			data = new SimpleDateFormat("yyyy-MM-dd").parse(dataSpettacolo);
		}catch(Exception e ){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		String treD = request.getParameter("treD");
		String numeroPostiLiberi = request.getParameter("posti");
		
		if(treD == null){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		
		if((numeroPostiLiberi == null)|| (numeroPostiLiberi.length() == 0)){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		int posti = 0;
		try{
			posti = Integer.parseInt(numeroPostiLiberi);
		}catch(Exception e){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		String idFilm1 = request.getParameter("idFilm");
		String idSala1 = request.getParameter("idSala");
		
		if((idFilm1 == null)|| (idFilm1.length() == 0)){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		int idFilm = 0;
		try{
			idFilm = Integer.parseInt(idFilm1);
		}catch(Exception e){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		if((idFilm1 == null)|| (idFilm1.length() == 0)){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		int idSala = 0;
		try{
			idSala = Integer.parseInt(idSala1);
		}catch(Exception e){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		SpettacoloModelDM modelSpettacolo = new SpettacoloModelDM();
		SpettacoloBean spettacolo = new SpettacoloBean();
		try {
			int id = 1;
			Collection<SpettacoloBean> coll = modelSpettacolo.doRetrieveAll();
			
			if(coll == null || coll.isEmpty()){
				spettacolo.setIdSpettacolo(id);
			}else{
				id = coll.size() + id;
				spettacolo.setIdSpettacolo(id);
			}
			spettacolo.setDataSpettacolo(data);
			spettacolo.setTreD(treD);
			spettacolo.setNumeroPostiLiberi(posti);
			spettacolo.setIdFilm(idFilm);
			spettacolo.setIdSala(idSala);
			modelSpettacolo.doSave(spettacolo);

		} catch (SQLException e) {
			e.printStackTrace();
			response.getWriter().write(BADREQUEST_MESS);
		}

		if(spettacolo != null){
			session.setAttribute("idSpett", spettacolo.getIdSpettacolo());
			
			response.getWriter().write("ok");
		}
	}
		
	
	 /** messaggio di errore inviato in caso di bad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";
}
