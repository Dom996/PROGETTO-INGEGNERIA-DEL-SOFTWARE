package control;

import java.io.IOException;
import java.util.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PromozioneBean;
import model.PromozioneModelDM;

/**
 * Servlet implementation class AggiuntaPromozioneServlet
 */
@WebServlet(name = "/AggiuntaPromozioneServlet", urlPatterns = "/aggiuntaPromozione")
public class AggiuntaPromozioneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AggiuntaPromozioneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nomePromozione = request.getParameter("nome");
		String durataPromozione = request.getParameter("durata");
		
		if(nomePromozione == null){
			response.getWriter().write(BADREQUEST_MESS);
			
			return;
		}
	
		/*if(durataPromozione == null){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}*/
		Date durata = null;
		try{
			durata = new SimpleDateFormat("yyyy-MM-dd").parse(durataPromozione);
		}catch(Exception e){
			response.getWriter().write(BADREQUEST_MESS);
		}		
		PromozioneModelDM modelPromozione = new PromozioneModelDM();
		try{ 
			int id = 1;
			Collection<PromozioneBean> coll = modelPromozione.doRetrieveAll();
			PromozioneBean beanPromozione = new PromozioneBean();
			if(coll == null || coll.isEmpty()){
				beanPromozione.setIdPromozione(id);
			}else{
				
			id = coll.size() + id;
			beanPromozione.setIdPromozione(id);
			}
			beanPromozione.setNomePromozione(nomePromozione);
			beanPromozione.setDurataPromozione(durata);
			modelPromozione.doSave(beanPromozione);
			response.getWriter().write("ok");
		}catch (SQLException e){
			e.printStackTrace();
			response.getWriter().write(BADREQUEST_MESS);
		}
		
	}

	/** messaggio di errore inviato in caad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";
}
