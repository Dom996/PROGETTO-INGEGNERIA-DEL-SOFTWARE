package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.ClienteBean;
import bean.UtenteRegistratoBean;
import model.ClienteModel;
import model.ClienteModelDM;
import model.UtenteRegistratoModelDM;

/**
 * Consente di effettuare le operazioni di login e logout per un utente registrato.
 * 
 */
@WebServlet(name = "RegistrazioneServlet", urlPatterns = "/registrazione")
public class RegistrazioneServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /** Default constructor. */
  public RegistrazioneServlet() {
	  
  }

  /**
   * doGet.
   * 
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
	  response.getWriter().write(BADREQUEST_MESS);
      return;
  }

  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    HttpSession session = request.getSession();
    String action = request.getParameter("action");
    if(action == null){
    	response.getWriter().write(BADREQUEST_MESS);
        return;
    }else if(action.equalsIgnoreCase("ModificaProfilo")){
    	String nome = request.getParameter("nome");
        if((nome == null)||(nome.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS);
            return;
        }
        String cognome = request.getParameter("cognome");
        if((cognome == null)||(cognome.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS);
            return;
        }

        String etaS = request.getParameter("eta");
        if((etaS == null)||(etaS.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS);
            return;
        }
        int eta;
        try {
    	eta = Integer.parseInt(etaS);
    	} catch (Exception e) {
    		response.getWriter().write(BADREQUEST_MESS);
            return;
    	}
        
        String indirizzo = request.getParameter("indirizzo");
        if((indirizzo == null)||(indirizzo.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS);
            return;
        }
        String email = request.getParameter("email");
        if((email == null)||(email.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS);
            return;
        }
        String email2 = request.getParameter("emaildue");
        if((email2 == null)||(email2.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS);
            return;
        }
        
        String password = request.getParameter("password");
        if((password == null)||(password.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS);
            return;
        }
        
        UtenteRegistratoBean utenteRegistrato = new UtenteRegistratoBean();
        utenteRegistrato.setEmail(email);
        utenteRegistrato.setPassword(password);
        utenteRegistrato.setTipologia("cliente");
         
        ClienteBean cliente = new ClienteBean();
        cliente.setNome(nome);
        cliente.setCognome(cognome);
        cliente.setEt�(eta);
        cliente.setIndirizzo(indirizzo);
        cliente.setEmail(email);
        
        UtenteRegistratoModelDM modelUtente = new UtenteRegistratoModelDM();
        try {
    		modelUtente.update(utenteRegistrato,email2);
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		response.getWriter().write(BADREQUEST_MESS);
    	}
        ClienteModelDM modelCliente = new ClienteModelDM();
        try {
    		modelCliente.update(cliente,email2);
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		response.getWriter().write(BADREQUEST_MESS);
    	}
        
        if (cliente != null) {
            session.setAttribute("Email", cliente.getEmail());
            session.setAttribute("Ruolo", "cliente");

            
       	 response.getWriter().write("ok");
          } 

    	
    }else if(action.equalsIgnoreCase("Registrazione")){
    	
    String nome = request.getParameter("nome");
    if((nome == null)||(nome.length()<2)) {
    	response.getWriter().write(BADREQUEST_MESS);
    	return;
    }
    String cognome = request.getParameter("cognome");
    if((cognome == null)||(cognome.length()<2)) {
    	response.getWriter().write(BADREQUEST_MESS);
    	return;
    }

    String etaS = request.getParameter("eta");
    if((etaS == null)||(etaS.length()<2)) {
    	response.getWriter().write(BADREQUEST_MESS);
    	return;
    }
    int eta;
    try {
	eta = Integer.parseInt(etaS);
	} catch (Exception e) {
		response.getWriter().write(BADREQUEST_MESS);
		return;
	}
    
    String indirizzo = request.getParameter("indirizzo");
    if((indirizzo == null)||(indirizzo.length()<2)) {
    	response.getWriter().write(BADREQUEST_MESS);
    	return;
    }
    String email = request.getParameter("email");
    if((email == null)||(email.length()<2)) {
    	response.getWriter().write(BADREQUEST_MESS);
    	return;
    }
    
    String password = request.getParameter("password");
    if((password == null)||(password.length()<2)) {
    	response.getWriter().write(BADREQUEST_MESS);
    	return;
    }
    
    UtenteRegistratoBean utenteRegistrato = new UtenteRegistratoBean();
    utenteRegistrato.setEmail(email);
    utenteRegistrato.setPassword(password);
    utenteRegistrato.setTipologia("cliente");
     
    ClienteBean cliente = new ClienteBean();
    cliente.setNome(nome);
    cliente.setCognome(cognome);
    cliente.setEt�(eta);
    cliente.setIndirizzo(indirizzo);
    cliente.setEmail(email);
    
    UtenteRegistratoModelDM modelUtente = new UtenteRegistratoModelDM();
    try {
		modelUtente.doSave(utenteRegistrato);
		System.out.println("Salvato utente");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		response.getWriter().write(BADREQUEST_MESS);
	}
    ClienteModelDM modelCliente = new ClienteModelDM();
    try {
		modelCliente.doSave(cliente);
		System.out.println("Salvato cliente");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		response.getWriter().write(BADREQUEST_MESS);
	}
    
    if (cliente != null) {
        session.setAttribute("Email", cliente.getEmail());
        session.setAttribute("Ruolo", "cliente");

   	 response.getWriter().write("ok");
   	 return;
      } 
    }else{
    	response.getWriter().write(BADREQUEST_MESS);
    	return;
    }
      
  }

  /** messaggio di errore inviato in caso di bad request. **/
  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

  /** messaggio restituito in caso di successo dell'operazione. **/
  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";
}
