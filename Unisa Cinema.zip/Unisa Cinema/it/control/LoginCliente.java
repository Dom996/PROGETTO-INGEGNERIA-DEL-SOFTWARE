package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.Request;

import bean.ClienteBean;
import bean.UtenteRegistratoBean;
import model.UtenteRegistratoModelDM;

/**
 * Servlet implementation class LoginCliente
 */
@WebServlet("/LoginCliente")
public class LoginCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginCliente() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		UtenteRegistratoModelDM model = new UtenteRegistratoModelDM();
		String mail = request.getParameter("email");
		String password = request.getParameter("password");
		
			try {
				UtenteRegistratoBean utente = model.doRetrieveByKey(mail);
				
				if(utente == null){
					//non sei registrato
					response.sendRedirect("home.jsp");
					return;
				}
				else if(utente.getPassword().equals(password)){
					request.getSession().setAttribute("email", utente.getEmail());
					request.getSession().setAttribute("tipologia", utente.getTipologia());
				
				
					if(utente.getTipologia().equals("cliente")){
						response.sendRedirect("home.jsp");
						return;
					}
				
					if(utente.getTipologia().equals("admin")){
						response.sendRedirect("areaPersonale.jsp");
						return;
					}
					
					if(utente.getTipologia().equals("operatore")){
						response.sendRedirect("areaPersonale.jsp");
						return;
				}
					
			}else{
					request.setAttribute("mail", mail);
					request.setAttribute("pwErrata", true);
					RequestDispatcher dispatcher = request.getRequestDispatcher("PaginaErrore.jsp");
					dispatcher.forward(request, response);
					return;
				}
				
			}catch(SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					response.sendRedirect("contattiDipartimento.jsp");
					return;
			}
	}
}
