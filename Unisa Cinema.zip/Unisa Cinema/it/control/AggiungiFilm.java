package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.text.html.HTMLDocument.Iterator;

import bean.FilmBean;
import model.FilmModelDM;

/**
 * Servlet implementation class AggiungiFilm
 */
@WebServlet(name= "AggiungiFilm", urlPatterns="/aggiungiFilm")
public class AggiungiFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AggiungiFilm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().write("no");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		if(action == null){
			response.getWriter().write(BADREQUEST_MESS+"1");
			return;
		}
		String img= request.getParameter("img");
		String genere = request.getParameter("genere");
		String durata = request.getParameter("durata");
		String regia = request.getParameter("regia");
		String trama = request.getParameter("trama");
		String nome = request.getParameter("nome");
		
		if((img == null)) {
        	response.getWriter().write(BADREQUEST_MESS+"2");
            return;
        }
		
	
		
		if((genere == null)||(genere.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS+"3");
            return;
        }
		if((durata == null)||(durata.length()<1)) {
        	response.getWriter().write(BADREQUEST_MESS+"4");
            return;
        }
		int dur=0;
		dur  = Integer.parseInt(durata);
		
		if((regia == null)||(regia.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS+"5");
            return;
        }
		
		if((trama == null)||(trama.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS+"6");
            return;
        }
		
		if((nome == null)||(nome.length()<2)) {
        	response.getWriter().write(BADREQUEST_MESS+"7");
            return;
        }
		
		if(action.equalsIgnoreCase("aggiungiFilm")){
		
		FilmBean beanFilm = new FilmBean();
		
		FilmModelDM modelFilm = new FilmModelDM();
		
		try {
			Collection<FilmBean> coll = modelFilm.doRetrieveAll();
			if((coll==null)||(coll.isEmpty())) {
				beanFilm.setIdFilm(1);
			}else{
				beanFilm.setIdFilm(coll.size() + 1);
			}String img1 = img.substring(12);
			beanFilm.setDurata(dur);beanFilm.setGenere(genere);
			beanFilm.setRegiaFilm(regia);
			beanFilm.setNomeFilm(nome);
			beanFilm.setTrama(trama);
			beanFilm.setImg(img1);
			modelFilm.doSave(beanFilm);
			response.getWriter().write("ok");
			
		} catch (SQLException e) {
			e.printStackTrace();
			response.getWriter().write(BADREQUEST_MESS+"8");
		}
	/*}else if(action.equalsIgnoreCase("CancellaFilm")){
		FilmModelDM model = new FilmModelDM();
		
		boolean success = false;

		try {

					String idFilm = request.getParameter("id");
					int id = Integer.parseInt(idFilm);
					
					success = model.doDelete(id);
				
			
		} catch (SQLException e) {
			e.printStackTrace();
			response.getWriter().write("no");
		}	
		if (success) {
			response.getWriter().write("ok");
		} else {
			response.getWriter().write("no");
		}*/
		
	}else if(action.equalsIgnoreCase("modificaFilm")){
		boolean successUp = false;
		String idf = request.getParameter("id");
		int idFilmBean = Integer.parseInt(idf);
		FilmModelDM model1 = new FilmModelDM();
		FilmBean be = new FilmBean();
		be.setDurata(dur);
		be.setIdFilm(idFilmBean);
		be.setGenere(genere);
		be.setRegiaFilm(regia);
		be.setNomeFilm(nome);
		be.setTrama(trama);
		be.setImg(img);
		try {
			successUp = model1.Update(be);
			if (successUp) {
				response.getWriter().write("ok");
			} else {
				response.getWriter().write("no");
			}
		} catch (SQLException e) {
			response.getWriter().write("no");
		}
	}
		
	}
	 /** messaggio di errore inviato in caso di bad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";
}
