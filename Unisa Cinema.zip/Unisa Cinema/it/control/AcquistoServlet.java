package control;

import java.io.IOException;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.OrdineBean;
import model.OrdineModelDM;

/**
 * Servlet implementation class AcquistoServlet
 */
@WebServlet(name= "AcquistoServlet", urlPatterns="/acquistoServlet")
public class AcquistoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private OrdineModelDM model = new OrdineModelDM();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AcquistoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idSpettacoloParam = request.getParameter("idSpettacolo");
		String pagamentoParam = request.getParameter("pagamento");
		String ritiroParam = request.getParameter("ritiro");
		String postiStr = request.getParameter("postiStr");
		String emailCliente = (String) request.getSession().getAttribute("email");
		if (emailCliente == null) {
			emailCliente = "clienteProvaEmail@email.com";
		}
		int numOrdine;
		if (idSpettacoloParam!= null && pagamentoParam!=null && ritiroParam!=null && postiStr!=null && emailCliente!=null) {
			System.out.println(idSpettacoloParam);
			System.out.println(pagamentoParam);
			System.out.println(ritiroParam);
			System.out.println(postiStr);
			int numeroBigliettiAcquistati = postiStr.split("-").length;
			OrdineBean ordine = new OrdineBean();
			ordine.setEmailCliente(emailCliente);
			ordine.setNumeroBigliettiAcquistati(numeroBigliettiAcquistati);
			ordine.setSceltaPagamento(pagamentoParam);
			ordine.setSceltaPoltrona(postiStr);
			ordine.setSceltaRitiro(ritiroParam);
			try {
				model.doSave(ordine);
				Iterator<OrdineBean> it =model.doRetrieveAll().iterator();
				while (it.hasNext()) {
					ordine = it.next();
				}
				numOrdine = ordine.getNumeroOrdine();
			}
			catch (Exception e) {
				response.getWriter().write("Si e' verificato un errore");
				return;
			}
			response.getWriter().write("L'operazione e' avvenuta con successo! Il tuo numero ordine e' "+numOrdine);
			return;
		}
		response.getWriter().write("L'operazione richiesta non e' valida.");
		System.out.println(idSpettacoloParam);
		System.out.println(pagamentoParam);
		System.out.println(ritiroParam);
		System.out.println(postiStr);
		System.out.println(emailCliente);
		return;
	}

}
