package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.FilmBean;
import model.FilmModelDM;

/**
 * Servlet implementation class RicercaFilm
 */
@WebServlet(name = "/RicercaFilm", urlPatterns = "/ricerca")
public class RicercaFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RicercaFilm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		FilmModelDM model = new FilmModelDM();
		String ricerca = request.getParameter("search");
		if((ricerca==null)||(ricerca.length()==0)){

			response.getWriter().write("no");
		}
		
		String tipo = request.getParameter("tipo");
		if((tipo==null)||(tipo.length()==0)){

			response.getWriter().write("no");
		}
					
		request.removeAttribute("campo");
		request.setAttribute("campo", ricerca);
		request.removeAttribute("tipo");
		request.setAttribute("tipo", tipo);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/Ricerca.jsp?tipo="+tipo+"&campo="+ricerca);


		dispatcher.forward(request, response);
	}
	/** messaggio di errore inviato in caad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";

}
