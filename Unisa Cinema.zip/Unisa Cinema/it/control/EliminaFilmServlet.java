package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.FilmBean;
import model.FilmModelDM;

/**
 * Servlet implementation class EliminaFilmServlet
 */
@WebServlet(name = "EliminaFilmServlet", urlPatterns = "/eliminaFilm")
public class EliminaFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EliminaFilmServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		FilmModelDM model = new FilmModelDM();
		String action = request.getParameter("action");
		boolean success = false;

		try {
			if (action != null) {

				if (action.equalsIgnoreCase("delete")) {
					String idFilm = request.getParameter("idFilm");
					int id = Integer.parseInt(idFilm);
					success = model.doDelete(id);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.getWriter().write("no");
		}
		if (success) {
			response.getWriter().write("ok");
		} else {
			response.getWriter().write("no");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
}
