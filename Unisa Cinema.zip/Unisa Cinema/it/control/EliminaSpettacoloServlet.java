package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.SpettacoloModelDM;


/**
 * Servlet implementation class EliminaSpettacoloServlet
 */
@WebServlet(name = "EliminaSpettacoloServlet", urlPatterns = "/eliminaSpettacolo")
public class EliminaSpettacoloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EliminaSpettacoloServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		SpettacoloModelDM model = new SpettacoloModelDM();
		String action = request.getParameter("action");
		boolean success = false;

		try {
			if (action != null) {

				if (action.equalsIgnoreCase("delete")) {
					String idSpett = request.getParameter("idSpett");
					int id = Integer.parseInt(idSpett);
					success = model.doDelete(id);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			response.getWriter().write("no");
		}
		if (success) {
			response.getWriter().write("ok");
		} else {
			response.getWriter().write("no");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
