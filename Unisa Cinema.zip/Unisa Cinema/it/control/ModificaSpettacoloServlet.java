package control;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.FilmBean;
import bean.SpettacoloBean;
import model.FilmModelDM;
import model.SpettacoloModelDM;

/**
 * Servlet implementation class ModificaFilmServlet
 */
@WebServlet(name = "/ModificaSpettacoloServlet", urlPatterns ="/modifica")
public class ModificaSpettacoloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModificaSpettacoloServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String idSpettacoloStr = request.getParameter("idSpett");
		if (idSpettacoloStr == null) {
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		int idSpett = 0;
		try {
			idSpett = Integer.parseInt(idSpettacoloStr);
		}
		catch (Exception e) {
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		String dataSpettacolo = request.getParameter("data");
		if((dataSpettacolo == null)){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		Date data = null;
		try{
			data = new SimpleDateFormat("yyyy-MM-dd").parse(dataSpettacolo);
		}catch(Exception e ){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		String treD = request.getParameter("treD");
		String numeroPostiLiberi = request.getParameter("posti");
		
		if(treD == null){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		
		if((numeroPostiLiberi == null)|| (numeroPostiLiberi.length() == 0)){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		int posti = 0;
		try{
			posti = Integer.parseInt(numeroPostiLiberi);
		}catch(Exception e){
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		
		SpettacoloModelDM modelSpettacolo = new SpettacoloModelDM();
		try {
		SpettacoloBean spettacolo = modelSpettacolo.doRetrieveByKey(idSpett);
			spettacolo.setDataSpettacolo(data);
			spettacolo.setTreD(treD);
			spettacolo.setNumeroPostiLiberi(posti);
			modelSpettacolo.update(spettacolo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			response.getWriter().write(BADREQUEST_MESS);
			return;
		}
		response.getWriter().write("ok");
	}
	
	/** messaggio di errore inviato in caso di bad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";

}
