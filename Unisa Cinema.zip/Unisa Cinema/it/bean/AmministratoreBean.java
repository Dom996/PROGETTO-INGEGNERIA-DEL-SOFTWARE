package bean;

import java.io.Serializable;

public class AmministratoreBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String email;
	private String nome;
	private String cognome;
	private int eta;
	private String indirizzo;
	
	public int getEta() {
		return eta;
	}

	public void setEta(int eta) {
		this.eta = eta;
	}
	
	public int getEt�() {
		return eta;
	}

	public void setEt�(int eta) {
		this.eta = eta;
	}
	
	public AmministratoreBean() {
		this.email = "";
		this.nome = "";
		this.cognome = "";
		this.eta = 0;
		this.indirizzo = "";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
}
