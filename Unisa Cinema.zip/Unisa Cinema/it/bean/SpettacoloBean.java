package bean;

import java.io.Serializable;
import java.util.Date;

public class SpettacoloBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int idSpettacolo;
	private Date dataSpettacolo;
	private String treD;
	private int numeroPostiLiberi;
	private int idFilm;
	private int idSala;
	
	public int getIdFilm() {
		return idFilm;
	}

	public void setIdFilm(int idFilm) {
		this.idFilm = idFilm;
	}

	public int getIdSala() {
		return idSala;
	}

	public void setIdSala(int idSala) {
		this.idSala = idSala;
	}

	public SpettacoloBean(){
		this.idFilm = 0;
		this.idSala = 0;
		this.idSpettacolo = 0;
		this.dataSpettacolo = null;
		this.treD = "";
		this.numeroPostiLiberi = 0;
	}

	public int getIdSpettacolo() {
		return idSpettacolo;
	}

	public void setIdSpettacolo(int idSpettacolo) {
		this.idSpettacolo = idSpettacolo;
	}

	public Date getDataSpettacolo() {
		return dataSpettacolo;
	}

	public void setDataSpettacolo(Date dataSpettacolo) {
		this.dataSpettacolo = dataSpettacolo;
	}

	public String getTreD() {
		return treD;
	}

	public void setTreD(String treD) {
		this.treD = treD;
	}

	public int getNumeroPostiLiberi() {
		return numeroPostiLiberi;
	}

	public void setNumeroPostiLiberi(int numeroPostiLiberi) {
		this.numeroPostiLiberi = numeroPostiLiberi;
	}
}
