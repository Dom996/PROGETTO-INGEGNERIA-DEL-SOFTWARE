package bean;

import java.io.Serializable;

public class OrdineBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String emailCliente;
	private int numeroOrdine;
	private int numeroBigliettiAcquistati;
	private String sceltaPagamento;
	private String sceltaRitiro;
	private String sceltaPoltrona;
	private String emailOperatore;
	
	public OrdineBean() {
		this.emailOperatore = "";
		this.emailCliente = "";
		this.numeroOrdine = 0;
		this.numeroBigliettiAcquistati = 0;
		this.sceltaPagamento = "";
		this.sceltaRitiro = "";
		this.sceltaPoltrona = "";
	}

	public String getEmailOperatore() {
		return emailOperatore;
	}

	public void setEmailOperatore(String emailOperatore) {
		this.emailOperatore = emailOperatore;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public int getNumeroOrdine() {
		return numeroOrdine;
	}

	public void setNumeroOrdine(int numeroOrdine) {
		this.numeroOrdine = numeroOrdine;
	}

	public int getNumeroBigliettiAcquistati() {
		return numeroBigliettiAcquistati;
	}

	public void setNumeroBigliettiAcquistati(int numeroBigliettiAcquistati) {
		this.numeroBigliettiAcquistati = numeroBigliettiAcquistati;
	}

	public String getSceltaPagamento() {
		return sceltaPagamento;
	}

	public void setSceltaPagamento(String sceltaPagamento) {
		this.sceltaPagamento = sceltaPagamento;
	}

	public String getSceltaRitiro() {
		return sceltaRitiro;
	}

	public void setSceltaRitiro(String sceltaRitiro) {
		this.sceltaRitiro = sceltaRitiro;
	}

	public String getSceltaPoltrona() {
		return sceltaPoltrona;
	}

	public void setSceltaPoltrona(String sceltaPoltrona) {
		this.sceltaPoltrona = sceltaPoltrona;
	}
}
