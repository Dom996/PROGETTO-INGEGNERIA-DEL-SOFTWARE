package bean;

import java.io.Serializable;

public class FilmBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int idFilm;
	private String nomeFilm;
	private String regiaFilm;
	private int durata;
	private String genere;
	private String trama;
	private String img;
	private String amministratoreEmail;
		
	public FilmBean() {
		super();
		this.idFilm = 0;
		this.nomeFilm = "";
		this.regiaFilm = "";
		this.durata = 0;
		this.genere = "";
		this.trama = "";
		this.img= "";
		this.amministratoreEmail = "";
	}

	public String getAmministratoreEmail() {
		return amministratoreEmail;
	}

	public void setAmministratoreEmail(String amministratoreEmail) {
		this.amministratoreEmail = amministratoreEmail;
	}

	public int getIdFilm() {
		return idFilm;
	}

	public void setIdFilm(int idFilm) {
		this.idFilm = idFilm;
	}

	public String getNomeFilm() {
		return nomeFilm;
	}

	public void setNomeFilm(String nomeFilm) {
		this.nomeFilm = nomeFilm;
	}

	public String getRegiaFilm() {
		return regiaFilm;
	}

	public void setRegiaFilm(String regiaFilm) {
		this.regiaFilm = regiaFilm;
	}

	public int getDurata() {
		return durata;
	}

	public void setDurata(int durata) {
		this.durata = durata;
	}

	public String getGenere() {
		return genere;
	}

	public void setGenere(String genere) {
		this.genere = genere;
	}

	public String getTrama() {
		return trama;
	}

	public void setTrama(String trama) {
		this.trama = trama;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}
	
	
}
