package bean;

import java.io.Serializable;

public class SalaBean implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int idSala;
	private int numeriPostiDisponibili;
	
	public SalaBean(){
		this.idSala = 0;
		this.numeriPostiDisponibili = 0;
	}

	public int getIdSala() {
		return idSala;
	}

	public void setIdSala(int idSala) {
		this.idSala = idSala;
	}

	public int getNumeriPostiDisponibili() {
		return numeriPostiDisponibili;
	}

	public void setNumeriPostiDisponibili(int numeriPostiDisponibili) {
		this.numeriPostiDisponibili = numeriPostiDisponibili;
	}
	
	
}
