package bean;

import java.io.Serializable;

public class BigliettoBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int codiceBiglietto;
	private int prezzo;
	private int numeroOrdine;
	private int idSpettacolo;
	
	public BigliettoBean() {
		this.codiceBiglietto = 0;
		this.prezzo = 0;
		this.numeroOrdine = 0;
		this.idSpettacolo = 0;
	}

	public int getCodiceBiglietto() {
		return codiceBiglietto;
	}

	public void setCodiceBiglietto(int codiceBiglietto) {
		this.codiceBiglietto = codiceBiglietto;
	}

	public int getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}

	public int getNumeroOrdine() {
		return numeroOrdine;
	}

	public void setNumeroOrdine(int numeroOrdine) {
		this.numeroOrdine = numeroOrdine;
	}

	public int getIdSpettacolo() {
		return idSpettacolo;
	}

	public void setIdSpettacolo(int idSpettacolo) {
		this.idSpettacolo = idSpettacolo;
	}
}
