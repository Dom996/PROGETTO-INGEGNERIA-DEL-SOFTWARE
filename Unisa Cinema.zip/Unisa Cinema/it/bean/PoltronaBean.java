package bean;

import java.io.Serializable;

public class PoltronaBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int idPoltrona;
	private int numeroFila;
	private int numeroPosto;
	private boolean postoLibero;
	private int idSala;
	
	public PoltronaBean(){
		this.idPoltrona = 0;
		this.numeroFila = 0;
		this.numeroPosto = 0;
		this.postoLibero = false;
		this.idSala = 0;
	}

	public int getIdPoltrona() {
		return idPoltrona;
	}

	public void setIdPoltrona(int idPoltrona) {
		this.idPoltrona = idPoltrona;
	}

	public int getNumeroFila() {
		return numeroFila;
	}

	public void setNumeroFila(int numeroFila) {
		this.numeroFila = numeroFila;
	}

	public int getNumeroPosto() {
		return numeroPosto;
	}

	public void setNumeroPosto(int numeroPosto) {
		this.numeroPosto = numeroPosto;
	}

	public boolean isPostoLibero() {
		return postoLibero;
	}

	public void setPostoLibero(boolean postoLibero) {
		this.postoLibero = postoLibero;
	}

	public int getIdSala() {
		return idSala;
	}

	public void setIdSala(int idSala) {
		this.idSala = idSala;
	}
}
