package bean;

import java.io.Serializable;
import java.util.Date;

public class PromozioneBean implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int idPromozione;
	private String nomePromozione;
	private Date durataPromozione;
	
	public PromozioneBean(){
		this.idPromozione = 0;
		this.nomePromozione = "";
		this.durataPromozione = null;
	}

	public int getIdPromozione() {
		return idPromozione;
	}

	public void setIdPromozione(int idPromozione) {
		this.idPromozione = idPromozione;
	}

	public String getNomePromozione() {
		return nomePromozione;
	}

	public void setNomePromozione(String nomePromozione) {
		this.nomePromozione = nomePromozione;
	}

	public Date getDurataPromozione() {
		return durataPromozione;
	}

	public void setDurataPromozione(Date durataPromozione) {
		this.durataPromozione = durataPromozione;
	}
}
