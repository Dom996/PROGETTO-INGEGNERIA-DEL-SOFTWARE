package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.UtenteRegistratoBean;

public class UtenteRegistratoModelDM implements UtenteRegistratoModel{

	@Override
	public UtenteRegistratoBean doSave(UtenteRegistratoBean bean) throws SQLException {
		
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
       
        	sql = "INSERT INTO utenteRegistrato (email,password,tipologia)"
        					+ "VALUES (?,?,?)";
        try{
        connection = DriverManagerConnectionPool.getConnection();
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, bean.getEmail());
        preparedStatement.setString(2, bean.getPassword());
        preparedStatement.setString(3, bean.getTipologia());
        
        preparedStatement.executeUpdate();
        connection.commit();
        
            }
          finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}

	public UtenteRegistratoBean update(UtenteRegistratoBean bean, String email2) throws SQLException{
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        sql = "UPDATE utenteRegistrato set email = ?, password = ?, tipologia = ? where email = ?";
        
        try{
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, bean.getEmail());
            preparedStatement.setString(2, bean.getPassword());
            preparedStatement.setString(3, bean.getTipologia());
            preparedStatement.setString(4,email2);
            
            
            
            preparedStatement.executeUpdate();
            connection.commit();
            
                }
              finally {
                try{
                  if(preparedStatement != null)
                    preparedStatement.close();
                }finally {
                  if(connection != null)
                    connection.close();
                }
              }
    	return bean;
	}
	
	@Override
	public boolean doDelete(String email) throws SQLException {
		Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM utenteRegistrato WHERE email = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setString(1, email);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		    
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);

	}

	@Override
	public UtenteRegistratoBean doRetrieveByKey(String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		
		try{
			connection = DriverManagerConnectionPool.getConnection();

			String stringSQL = "SELECT * FROM utenteRegistrato WHERE email = ?;";
			
		
			preparedStatement = connection.prepareStatement(stringSQL);
			preparedStatement.setString(1, email);
		
			rs = preparedStatement.executeQuery();
			
			if(rs.next()){
				UtenteRegistratoBean bean = new UtenteRegistratoBean();
				bean.setEmail(rs.getString("email"));
				bean.setPassword(rs.getString("password"));
				bean.setTipologia(rs.getString("tipologia"));
				return bean;
				}else return null;
			
			}finally{
				try{
					if(connection.isClosed())
						connection.close();
			}finally {
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	@Override
	 public Collection<UtenteRegistratoBean> doRetrieveAll() throws SQLException {
	    Connection connection = null;
	    PreparedStatement preparedStatement = null;

	    Collection<UtenteRegistratoBean> utentiRegistrati = new LinkedList<UtenteRegistratoBean>();

	    String selectSQL = "SELECT * FROM utenteRegistrato";

	    try {
	      connection = DriverManagerConnectionPool.getConnection();
	      preparedStatement = connection.prepareStatement(selectSQL);

	      ResultSet rs = preparedStatement.executeQuery();

	        
	        while (rs.next()) {
	          UtenteRegistratoBean bean = new UtenteRegistratoBean();
	          bean.setEmail(rs.getString("email"));
	          bean.setPassword(rs.getString("password"));
	          bean.setTipologia(rs.getString("tipologia"));
	          utentiRegistrati.add(bean);
	        } 

	    } finally {
	      try {
	        if (preparedStatement != null)
	          preparedStatement.close();
	      } finally {
	        if (connection != null)
	          connection.close();
	      }
	    }
	    return utentiRegistrati;
	 }

}
