package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.OrdineBean;

public interface OrdineModel {

	public OrdineBean doSave(OrdineBean bean) throws SQLException;
	
	public boolean doDelete(int numeroOrdine) throws SQLException;
	
	public OrdineBean doRetrieveByKey(int numeroOrdine) throws SQLException;
	
	public Collection<OrdineBean> doRetrieveAll() throws SQLException;
}
