package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.FilmBean;
import bean.PoltronaBean;

public class PoltronaModelDM implements PoltronaModel{

	@Override
	 public PoltronaBean doSave(PoltronaBean bean) throws SQLException {
	  Connection connection = null;
	        PreparedStatement preparedStatement = null;
	        String sql;
	        
	         sql = "INSERT INTO poltrona (numeroFila,numeroPosto,postoLibero,idSala)"
	            + "VALUES (?,?,?,?)";
	      
	      try{
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(sql);
	        
	        preparedStatement.setInt(1,bean.getNumeroFila());
	        preparedStatement.setInt(2,bean.getNumeroPosto());
	        if(bean.isPostoLibero()) {
	         preparedStatement.setInt(3,0);
	        } else {
	         preparedStatement.setInt(3,1);
	        }
	        preparedStatement.setInt(4, bean.getIdSala());
	        
	     
	        preparedStatement.executeUpdate();
	        connection.commit();
	              
	            }
	          finally {
	            try{
	              if(preparedStatement != null)
	                preparedStatement.close();
	            }finally {
	              if(connection != null)
	                connection.close();
	            }
	          }
	 return bean;
	 }

	@Override
	public boolean doDelete(int idPoltrona) throws SQLException {
		
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM poltrona WHERE idPoltrona = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setInt(1, idPoltrona);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public PoltronaBean doRetrieveByKey(int idPoltrona) throws SQLException {
		  
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  PoltronaBean bean = null;

		  String selectSQL = "SELECT * FROM poltrona WHERE idPoltrona = ?"; 

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setInt(1, idPoltrona);

		    ResultSet rs = preparedStatement.executeQuery();

		    if (rs.next()) {
		    	bean = new PoltronaBean();
		      bean.setIdPoltrona(rs.getInt("idPoltrona"));
		      bean.setNumeroFila(rs.getInt("numeroFila"));
		      bean.setNumeroPosto(rs.getInt("numeroPosto"));
		      bean.setPostoLibero(rs.getBoolean("postoLibero"));
		      bean.setIdSala(rs.getInt("idSala"));
		    } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return bean;
	}

	@Override
	public Collection<PoltronaBean> doRetrieveAll() throws SQLException {
		  
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<PoltronaBean> poltrone = new LinkedList<PoltronaBean>();

		  String selectSQL = "SELECT * FROM poltrona";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		        PoltronaBean bean = new PoltronaBean();
		        bean.setIdPoltrona(rs.getInt("idPoltrona"));
		        bean.setNumeroFila(rs.getInt("numeroFila"));
		        bean.setNumeroPosto(rs.getInt("numeroPosto"));
		        bean.setPostoLibero(rs.getBoolean("postoLibero"));
		        bean.setIdSala(rs.getInt("idSala"));
		        poltrone.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return poltrone;
	}

}
