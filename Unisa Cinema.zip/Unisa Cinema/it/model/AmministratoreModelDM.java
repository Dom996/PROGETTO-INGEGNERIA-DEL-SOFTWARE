package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.AmministratoreBean;
import bean.ClienteBean;

public class AmministratoreModelDM implements AmministratoreModel {

	@Override
	public AmministratoreBean doSave(AmministratoreBean bean) throws SQLException {
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        	sql = "INSERT INTO amministratore (email,nome,cognome,et�,indirizzo)"
            + "VALUES (?,?,?,?,?)";
      
      try{
        connection = DriverManagerConnectionPool.getConnection();
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, bean.getEmail());
        preparedStatement.setString(2, bean.getNome());
        preparedStatement.setString(3, bean.getCognome());
        preparedStatement.setInt(4, bean.getEta());
        preparedStatement.setString(5, bean.getIndirizzo());
        
    	
        preparedStatement.executeUpdate();
        connection.commit();
              
            }
          finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}

	public AmministratoreBean update(AmministratoreBean bean , String oldKey)throws SQLException{
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        sql = "update amministratore set email = ?, nome = ?, cognome = ?, et� = ?, indirizzo = ?  where email = ?";
        
        try{
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, bean.getEmail());
            preparedStatement.setString(2, bean.getNome());
            preparedStatement.setString(3, bean.getCognome());
            preparedStatement.setInt(4, bean.getEta());
            preparedStatement.setString(5, bean.getIndirizzo());
            preparedStatement.setString(6, oldKey);
      
            preparedStatement.executeUpdate();
            connection.commit();
            
                }
              finally {
                try{
                  if(preparedStatement != null)
                    preparedStatement.close();
                }finally {
                  if(connection != null)
                    connection.close();
                }
              }
    	return bean;
	}
	
	@Override
	public boolean doDelete(String email) throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM amministratore WHERE email = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setString(1, email);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public AmministratoreBean doRetrieveByKey(String email) throws SQLException {
		Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  AmministratoreBean bean = null;

		  String selectSQL = "SELECT * FROM amministratore WHERE email = ?"; 

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setString(1, email);

		    ResultSet rs = preparedStatement.executeQuery();

		    if (rs.next()) {
		    	bean = new AmministratoreBean();
		    	bean.setEmail(rs.getString("email"));
		    	bean.setNome(rs.getString("nome"));
		    	bean.setCognome(rs.getString("cognome"));
		    	bean.setEta(rs.getInt("et�"));
		    	bean.setIndirizzo(rs.getString("indirizzo"));
		    } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return bean;
	}

	@Override
	public Collection<AmministratoreBean> doRetrieveAll() throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<AmministratoreBean> collection = new LinkedList<AmministratoreBean>();

		  String selectSQL = "SELECT * FROM amministratore";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		    	AmministratoreBean bean = new AmministratoreBean();
		        bean.setEmail(rs.getString("email"));
		        bean.setNome(rs.getString("nome"));
		        bean.setCognome(rs.getString("cognome"));
		        bean.setEta(rs.getInt("et�"));
		        bean.setIndirizzo(rs.getString("indirizzo"));
		        collection.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return collection;
		}

}
