package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.ClienteBean;
import bean.UtenteRegistratoBean;

public class ClienteModelDM implements ClienteModel{

	@Override
	public ClienteBean doSave(ClienteBean bean) throws SQLException {
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        	sql = "INSERT INTO cliente (email,nome,cognome,et�,indirizzo)"
            + "VALUES (?,?,?,?,?)";
      
      try{
        connection = DriverManagerConnectionPool.getConnection();
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, bean.getEmail());
        preparedStatement.setString(2, bean.getNome());
        preparedStatement.setString(3, bean.getCognome());
        preparedStatement.setInt(4, bean.getEta());
        preparedStatement.setString(5, bean.getIndirizzo());
        
    	
        preparedStatement.executeUpdate();
        connection.commit();
              
            }
          finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}

	public ClienteBean update(ClienteBean bean, String email2)throws SQLException{
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        sql = "update cliente set email = ?, nome = ?, cognome = ?, et� = ?, indirizzo = ?  where email = ?";
        
        try{
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, bean.getEmail());
            preparedStatement.setString(2, bean.getNome());
            preparedStatement.setString(3, bean.getCognome());
            preparedStatement.setInt(4, bean.getEta());
            preparedStatement.setString(5, bean.getIndirizzo());
            preparedStatement.setString(6,email2);
      
            preparedStatement.executeUpdate();
            connection.commit();
            
                }
              finally {
                try{
                  if(preparedStatement != null)
                    preparedStatement.close();
                }finally {
                  if(connection != null)
                    connection.close();
                }
              }
    	return bean;
	}
	
	@Override
	public boolean doDelete(String email) throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM cliente WHERE email = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setString(1, email);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		    
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public ClienteBean doRetrieveByKey(String email) throws SQLException {
		Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  ClienteBean bean = null;

		  String selectSQL = "SELECT * FROM cliente WHERE email = ?"; 

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setString(1, email);

		    ResultSet rs = preparedStatement.executeQuery();

		    if (rs.next()) {
		    	bean = new ClienteBean();
		    	bean.setEmail(rs.getString("email"));
		    	bean.setNome(rs.getString("nome"));
		    	bean.setCognome(rs.getString("cognome"));
		    	bean.setEta(rs.getInt("et�"));
		    	bean.setIndirizzo(rs.getString("indirizzo"));
		    } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return bean;
	}

	@Override
	public Collection<ClienteBean> doRetrieveAll() throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<ClienteBean> clienti = new LinkedList<ClienteBean>();

		  String selectSQL = "SELECT * FROM cliente";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		    	ClienteBean bean = new ClienteBean();
		        bean.setEmail(rs.getString("email"));
		        bean.setNome(rs.getString("nome"));
		        bean.setCognome(rs.getString("cognome"));
		        bean.setEta(rs.getInt("et�"));
		        bean.setIndirizzo(rs.getString("indirizzo"));
		        clienti.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return clienti;
		}
}
