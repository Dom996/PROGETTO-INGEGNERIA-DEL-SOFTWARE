package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.PoltronaBean;

public interface PoltronaModel {

	public PoltronaBean doSave(PoltronaBean bean) throws SQLException;
	
	public boolean doDelete(int idPoltrona) throws SQLException;
	
	public PoltronaBean doRetrieveByKey(int idPoltrona) throws SQLException;
	
	public Collection<PoltronaBean> doRetrieveAll() throws SQLException;
}
