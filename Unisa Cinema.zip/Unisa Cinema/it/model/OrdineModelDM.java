package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import bean.OrdineBean;

public class OrdineModelDM implements OrdineModel{

	@Override
	public OrdineBean doSave(OrdineBean bean) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String insertSQL = "INSERT INTO ordine (cliente_email,numeroBigliettiAcquistati,"
							+ "sceltaPagamento,sceltaRitiro,sceltaPoltrona,operatore_email)"
							+ "	VALUES (?,?,?,?,?,?)";
		
		try{
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(insertSQL);
	        preparedStatement.setString(1, bean.getEmailCliente());
	        preparedStatement.setInt(2, bean.getNumeroBigliettiAcquistati());
	        preparedStatement.setString(3, bean.getSceltaPagamento());
	        preparedStatement.setString(4, bean.getSceltaRitiro());
	        preparedStatement.setString(5, bean.getSceltaPoltrona());
	        preparedStatement.setString(6,  bean.getEmailOperatore());
	        preparedStatement.executeUpdate();
	        connection.commit();
		}
		finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}

	@Override
	public boolean doDelete(int numeroOrdine) throws SQLException {
		Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM ordine WHERE numeroOrdine = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setInt(1, numeroOrdine);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);

	}

	@Override
	 public OrdineBean doRetrieveByKey(int numeroOrdine) throws SQLException {
	    Connection connection = null;
	    PreparedStatement preparedStatement = null;

	    OrdineBean bean = null;
	    String selectSQL = "SELECT * FROM ordine WHERE numeroOrdine = ?"; 

	    try {
	      connection = DriverManagerConnectionPool.getConnection();
	      preparedStatement = connection.prepareStatement(selectSQL);
	      preparedStatement.setInt(1, numeroOrdine);

	      ResultSet rs = preparedStatement.executeQuery();

	      if (rs.next()) {
	    	  bean = new OrdineBean();
	        bean.setEmailCliente(rs.getString("cliente_email"));
	        bean.setEmailOperatore(rs.getString("operatore_email"));
	        bean.setNumeroBigliettiAcquistati(rs.getInt("numeroBigliettiAcquistati"));
	        bean.setNumeroOrdine(rs.getInt("numeroOrdine"));
	        bean.setSceltaPagamento(rs.getString("sceltaPagamento"));
	        bean.setSceltaRitiro(rs.getString("sceltaRitiro"));
	        bean.setSceltaPoltrona(rs.getString("sceltaPoltrona"));
	        
	      } 

	    } finally
	{
	      try {
	        if (preparedStatement != null)
	          preparedStatement.close();
	      } finally {
	        if (connection != null)
	          connection.close();
	      }
	    }
	    return bean;
	 }

	@Override
	public Collection<OrdineBean> doRetrieveAll() throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<OrdineBean> ordini = new LinkedList<OrdineBean>();

		  String selectSQL = "SELECT * FROM ordine";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		    	OrdineBean bean = new OrdineBean();
		        bean.setNumeroOrdine(rs.getInt("numeroOrdine"));
		        bean.setNumeroBigliettiAcquistati(rs.getInt("numeroBigliettiAcquistati"));
		        bean.setSceltaPagamento(rs.getString("sceltaPagamento"));
		        bean.setSceltaRitiro(rs.getString("sceltaRitiro"));
		        bean.setSceltaPoltrona(rs.getString("sceltaPoltrona"));
		       bean.setEmailCliente(rs.getString("cliente_email"));
		       bean.setEmailOperatore(rs.getString("operatore_email"));
		       
		        ordini.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return ordini;
		}

}
