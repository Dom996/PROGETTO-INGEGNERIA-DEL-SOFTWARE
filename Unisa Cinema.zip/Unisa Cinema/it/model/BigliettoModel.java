package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.BigliettoBean;

public interface BigliettoModel {

	public BigliettoBean doSave(BigliettoBean bean) throws SQLException;
	
	public boolean doDelete(int codiceBiglietto) throws SQLException;
	
	public BigliettoBean doRetrieveByKey(int codiceBiglietto) throws SQLException;
	
	public Collection<BigliettoBean> doRetrieveAll() throws SQLException;
}
