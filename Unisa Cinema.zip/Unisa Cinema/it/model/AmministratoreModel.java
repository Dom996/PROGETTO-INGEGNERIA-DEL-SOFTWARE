package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.AmministratoreBean;

public interface AmministratoreModel {

	
	public AmministratoreBean doSave(AmministratoreBean bean) throws SQLException;
	
	public boolean doDelete(String email) throws SQLException;
	
	public AmministratoreBean doRetrieveByKey(String email) throws SQLException;
	
	public Collection<AmministratoreBean> doRetrieveAll() throws SQLException;
}
