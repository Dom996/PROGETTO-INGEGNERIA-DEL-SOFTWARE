package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import bean.BigliettoBean;

public class BigliettoModelDM implements BigliettoModel{

	@Override
	public BigliettoBean doSave(BigliettoBean bean) throws SQLException { 
		  Connection connection = null; 
		        PreparedStatement preparedStatement = null; 
		 
		        String insertSQL = "INSERT INTO biglietto (prezzo,numeroOrdine,idSpettacolo)" 
		             + "VALUES (?,?,?)"; 
		      try{ 
		        connection = (Connection) DriverManagerConnectionPool.getConnection(); 
		        preparedStatement = (PreparedStatement) connection.prepareStatement(insertSQL); 
		        preparedStatement.setInt(1, bean.getPrezzo()); 
		        preparedStatement.setInt(2,bean.getNumeroOrdine()); 
		        preparedStatement.setInt(3,bean.getIdSpettacolo()); 
		         
		        preparedStatement.executeUpdate(); 
		        connection.commit(); 
		         
		            } 
		          finally { 
		            try{ 
		              if(preparedStatement != null) 
		                preparedStatement.close(); 
		            }finally { 
		              if(connection != null) 
		                connection.close(); 
		            } 
		          } 
		 return bean; 
		   
		 } 

	@Override
	public boolean doDelete(int codiceBiglietto) throws SQLException { 
		  Connection connection = null; 
		    PreparedStatement preparedStatement = null; 
		 
		    int result = 0; 
		 
		    String deleteSQL = "DELETE FROM biglietto WHERE codiceBiglietto = ?"; 
		 
		    try { 
		      connection = (Connection) DriverManagerConnectionPool.getConnection(); 
		      preparedStatement = (PreparedStatement) connection.prepareStatement(deleteSQL); 
		      preparedStatement.setInt(1, codiceBiglietto); 
		 
		      result = preparedStatement.executeUpdate(); 
		      connection.commit();
		      
		    } finally { 
		      try { 
		        if (preparedStatement != null) 
		          preparedStatement.close(); 
		      } finally { 
		        if (connection != null) 
		          connection.close(); 
		      } 
		    } 
		    return (result != 0); 
		 
		 } 

	@Override
	public BigliettoBean doRetrieveByKey(int codiceBiglietto) throws SQLException { 
		  Connection connection = null; 
		    PreparedStatement preparedStatement = null; 
		 
		    BigliettoBean bean = null; 
		 
		    String selectSQL = "SELECT * FROM biglietto WHERE codiceBiglietto = ?";  
		 
		    try { 
		      connection = (Connection) DriverManagerConnectionPool.getConnection(); 
		      preparedStatement = (PreparedStatement) connection.prepareStatement(selectSQL); 
		      preparedStatement.setInt(1, codiceBiglietto); 
		 
		      ResultSet rs = preparedStatement.executeQuery(); 
		 
		      if (rs.next()) { 
		        bean = new BigliettoBean();
		       bean.setCodiceBiglietto(rs.getInt("codiceBiglietto")); 
		       bean.setIdSpettacolo(rs.getInt("idSpettacolo")); 
		       bean.setNumeroOrdine(rs.getInt("numeroOrdine")); 
		       bean.setPrezzo(rs.getInt("prezzo")); 
		       
		      }  
		 
		    } finally { 
		      try { 
		        if (preparedStatement != null) 
		          preparedStatement.close(); 
		      } finally { 
		        if (connection != null) 
		          connection.close(); 
		      } 
		    } 
		    return bean; 
		 } 

	@Override
	public Collection<BigliettoBean> doRetrieveAll() throws SQLException { 
		  Connection connection = null; 
		    PreparedStatement preparedStatement = null; 
		 
		    Collection<BigliettoBean> collection = new LinkedList<BigliettoBean>(); 
		 
		    String selectSQL = "SELECT * FROM biglietto"; 
		 
		    try { 
		      connection = (Connection) DriverManagerConnectionPool.getConnection(); 
		      preparedStatement = (PreparedStatement) connection.prepareStatement(selectSQL); 
		 
		      ResultSet rs = preparedStatement.executeQuery(); 
		 
		         
		        while (rs.next()) { 
		         BigliettoBean bean = new BigliettoBean(); 
		          bean.setCodiceBiglietto(rs.getInt("codiceBiglietto")); 


		          bean.setPrezzo(rs.getInt("prezzo")); 
		          bean.setIdSpettacolo(rs.getInt("idSpettacolo")); 
		         bean.setNumeroOrdine(rs.getInt("numeroOrdine")); 
		          collection.add(bean); 
		        }  
		 
		    } finally { 
		      try { 
		        if (preparedStatement != null) 
		          preparedStatement.close(); 
		      } finally { 
		        if (connection != null) 
		          connection.close(); 
		      } 
		    } 
		    return collection; 
		 } 

}
