package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Collection;
import java.util.LinkedList;

import bean.FilmBean;
import bean.PoltronaBean;
import bean.PromozioneBean;

public class PromozioneModelDM implements PromozioneModel{

	@Override
	public PromozioneBean doSave(PromozioneBean bean) throws SQLException {
		
		Connection connection = null;
        PreparedStatement preparedStatement = null;

        String insertSQL = "INSERT INTO promozione (nomePromozione,durataPromozione) VALUES (?,?)";
      try{
        connection = DriverManagerConnectionPool.getConnection();
        preparedStatement = connection.prepareStatement(insertSQL);
        preparedStatement.setString(1, bean.getNomePromozione());
        java.sql.Date date = new java.sql.Date(bean.getDurataPromozione().getTime());
        preparedStatement.setDate(2, date);
        
        preparedStatement.executeUpdate();
   
        connection.commit();
       
      	}
          finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}

	@Override
	public boolean doDelete(int idPromozione) throws SQLException {
		 
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM promozione WHERE idPromozione = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setInt(1, idPromozione);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public PromozioneBean doRetrieveByKey(int idPromozione) throws SQLException {
		
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  PromozioneBean bean = null;

		  String selectSQL = "SELECT * FROM promozione WHERE idPromozione = ?"; 

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setInt(1, idPromozione);

		    ResultSet rs = preparedStatement.executeQuery();

		    if (rs.next()) {
		    	bean = new PromozioneBean();
		      bean.setIdPromozione(rs.getInt("idPromozione"));
		      bean.setNomePromozione(rs.getString("nomePromozione"));
		      bean.setDurataPromozione(rs.getDate("durataPromozione"));
		    } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return bean;
	}

	@Override
	public Collection<PromozioneBean> doRetrieveAll() throws SQLException {

		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<PromozioneBean> promozioni = new LinkedList<PromozioneBean>();

		  String selectSQL = "SELECT * FROM promozione";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		        PromozioneBean bean = new PromozioneBean();
		        bean.setIdPromozione(rs.getInt("idPromozione"));
		        bean.setNomePromozione(rs.getString("nomePromozione"));
		        bean.setDurataPromozione(rs.getDate("durataPromozione"));
		        promozioni.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return promozioni;
	}

}
