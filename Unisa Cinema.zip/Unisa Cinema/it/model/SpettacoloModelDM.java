package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.ClienteBean;
import bean.PromozioneBean;
import bean.SpettacoloBean;

public class SpettacoloModelDM implements SpettacoloModel{

	@Override
	public SpettacoloBean doSave(SpettacoloBean bean) throws SQLException {
		Connection connection = null;
        PreparedStatement preparedStatement = null;

        String insertSQL = "INSERT INTO spettacolo (dataSpettacolo,treD,numeriPostiLiberi,idFilm,idSala) VALUES (?,?,?,?,?)";
      try{
        connection = DriverManagerConnectionPool.getConnection();
        preparedStatement = connection.prepareStatement(insertSQL); 
        java.sql.Date date = new java.sql.Date(bean.getDataSpettacolo().getTime());
        preparedStatement.setDate(1,date);
        preparedStatement.setString(2, bean.getTreD());
        preparedStatement.setInt(3, bean.getNumeroPostiLiberi());
        preparedStatement.setInt(4,bean.getIdFilm());
        preparedStatement.setInt(5,bean.getIdSala());
        
        preparedStatement.executeUpdate();
        connection.commit();
        
            }
          finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}
	
	public SpettacoloBean update(SpettacoloBean idSpett)throws SQLException{
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        sql = "update spettacolo set idSpettacolo = ?, dataSpettacolo = ?, treD = ?, numeriPostiLiberi = ?  where idSpettacolo = ?";
        
        try{
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            
            preparedStatement.setInt(1, idSpett.getIdSpettacolo());
            java.sql.Date date = new java.sql.Date(idSpett.getDataSpettacolo().getTime());
            preparedStatement.setDate(2, date);
            preparedStatement.setString(3, idSpett.getTreD());
            preparedStatement.setInt(4, idSpett.getNumeroPostiLiberi());
            preparedStatement.setInt(5, idSpett.getIdSpettacolo());
            
      
            preparedStatement.executeUpdate();
            connection.commit();
            
                }
              finally {
                try{
                  if(preparedStatement != null)
                    preparedStatement.close();
                }finally {
                  if(connection != null)
                    connection.close();
                }
              }
    	return idSpett;
	}

	@Override
	public boolean doDelete(int idSpett) throws SQLException {
		  
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM spettacolo WHERE idSpettacolo = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setInt(1, idSpett);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public SpettacoloBean doRetrieveByKey(int idSpett) throws SQLException {
		
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  SpettacoloBean bean = null;

		  String selectSQL = "SELECT * FROM spettacolo WHERE idSpettacolo = ?"; 

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setInt(1, idSpett);

		    ResultSet rs = preparedStatement.executeQuery();

		    if (rs.next()) {
		    	bean = new SpettacoloBean();
		    	bean.setIdFilm(rs.getInt("idFilm"));
		    	bean.setIdSala(rs.getInt("idSala"));
		      bean.setIdSpettacolo(rs.getInt("idSpettacolo"));
		      bean.setDataSpettacolo(rs.getDate("dataSpettacolo"));
		      bean.setTreD(rs.getString("treD"));
		      bean.setNumeroPostiLiberi(rs.getInt("numeriPostiLiberi"));
		    } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return bean;
	}

	@Override
	public Collection<SpettacoloBean> doRetrieveAll() throws SQLException {
		
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<SpettacoloBean> spettacoli = new LinkedList<SpettacoloBean>();

		  String selectSQL = "SELECT * FROM spettacolo";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		        SpettacoloBean bean = new SpettacoloBean();
		        bean.setIdSpettacolo(rs.getInt("idSpettacolo"));
		        bean.setDataSpettacolo(rs.getDate("dataSpettacolo"));
			    bean.setTreD(rs.getString("treD"));
			    bean.setNumeroPostiLiberi(rs.getInt("numeriPostiLiberi"));
			    bean.setIdFilm(rs.getInt("idFilm"));
			    bean.setIdSala(rs.getInt("idSala"));
		        spettacoli.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return spettacoli;
	}

	
	
	public Collection<SpettacoloBean> findByIdFilm(int idFilm) throws SQLException {

		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<SpettacoloBean> spettacoli = new LinkedList<SpettacoloBean>();

		  String selectSQL = "SELECT * FROM spettacolo WHERE idFilm = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setInt(1, idFilm);
		    ResultSet rs = preparedStatement.executeQuery();
		      
		      while (rs.next()) {
		        SpettacoloBean bean = new SpettacoloBean();
		        bean.setIdSpettacolo(rs.getInt("idSpettacolo"));
		        bean.setDataSpettacolo(rs.getDate("dataSpettacolo"));
			    bean.setTreD(rs.getString("treD"));
			    bean.setNumeroPostiLiberi(rs.getInt("numeriPostiLiberi"));
			    bean.setIdFilm(rs.getInt("idFilm"));
			    bean.setIdSala(rs.getInt("idSala"));
		        spettacoli.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return spettacoli;
	}
}
