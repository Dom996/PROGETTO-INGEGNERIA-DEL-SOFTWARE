package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.SpettacoloBean;

public interface SpettacoloModel {

	public SpettacoloBean doSave(SpettacoloBean bean) throws SQLException;
	
	public boolean doDelete(int idSpett) throws SQLException;
	
	public SpettacoloBean doRetrieveByKey(int idSpett) throws SQLException;
	
	public Collection<SpettacoloBean> doRetrieveAll() throws SQLException;
}
