package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.FilmBean;

public class FilmModelDM implements FilmModel{

	@Override
	public FilmBean doSave(FilmBean bean) throws SQLException {

	        Connection connection = null;
	        PreparedStatement preparedStatement = null;

	        String insertSQL = "INSERT INTO film (img,nomeFilm,regiaFilm,"
	        					+ "durataFilm,genereFilm,tramaFilm)"
	        					+ "VALUES (?,?,?,?,?,?)";
	      try{
	        connection = DriverManagerConnectionPool.getConnection();
	        preparedStatement = connection.prepareStatement(insertSQL);
	        preparedStatement.setString(1, bean.getImg());
	        preparedStatement.setString(2, bean.getNomeFilm());
	        preparedStatement.setString(3, bean.getRegiaFilm());
	        preparedStatement.setInt(4, bean.getDurata());
	        preparedStatement.setString(5, bean.getGenere());
	        preparedStatement.setString(6, bean.getTrama());
	        
	        preparedStatement.executeUpdate();
	        connection.commit();
	        
	            }
	          finally {
	            try{
	              if(preparedStatement != null)
	                preparedStatement.close();
	            }finally {
	              if(connection != null)
	                connection.close();
	            }
	          }
		return bean;
	}

	@Override
	public boolean doDelete(int idFilm) throws SQLException {
		  
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;
		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		  
		    String deleteSQL = "DELETE FROM film WHERE idFilm = ?";

		    preparedStatement = connection.prepareStatement(deleteSQL);
		    
		    preparedStatement.setInt(1, idFilm);

		    result =  preparedStatement.executeUpdate();
		  if (result == 1)  connection.commit();
		    

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public FilmBean doRetrieveByKey(int idFilm) throws SQLException {
	
	  Connection connection = null;
	  PreparedStatement preparedStatement = null;

	  FilmBean bean = null;

	  String selectSQL = "SELECT * FROM film WHERE idFilm = ?"; 

	  try {
	    connection = DriverManagerConnectionPool.getConnection();
	    preparedStatement = connection.prepareStatement(selectSQL);
	    preparedStatement.setInt(1, idFilm);

	    ResultSet rs = preparedStatement.executeQuery();

	    if (rs.next()) {
	    	bean = new FilmBean();
	      bean.setIdFilm(rs.getInt("idFilm"));
	      bean.setNomeFilm(rs.getString("nomeFilm"));
	      bean.setRegiaFilm(rs.getString("regiaFilm"));
	      bean.setDurata(rs.getInt("durataFilm"));
	      bean.setGenere(rs.getString("genereFilm"));
	      bean.setTrama(rs.getString("tramaFilm"));
	      bean.setImg(rs.getString("img"));
	    } 

	  } finally {
	    try {
	      if (preparedStatement != null)
	        preparedStatement.close();
	    } finally {
	      if (connection != null)
	        connection.close();
	    }
	  }
	  return bean;
	}

	@Override
	public Collection<FilmBean> doRetrieveAll() throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<FilmBean> film = new LinkedList<FilmBean>();

		  String selectSQL = "SELECT * FROM film";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		        FilmBean bean = new FilmBean();
		        bean.setIdFilm(rs.getInt("idFilm"));
		        bean.setNomeFilm(rs.getString("nomeFilm"));
		        bean.setRegiaFilm(rs.getString("regiaFilm"));
		        bean.setDurata(rs.getInt("durataFilm"));
		        bean.setGenere(rs.getString("genereFilm"));
		        bean.setTrama(rs.getString("tramaFilm"));
		        bean.setImg(rs.getString("img"));
		        film.add(bean);
		        connection.commit();
		      }

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return film;
	
        }
	
	public boolean Update(FilmBean film) throws SQLException{
		Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  FilmBean bean = film;
		  String selectSQL = "UPDATE film SET idFilm = ?,"+ 
		  		"nomeFilm = ?," + 
		  		"regiaFilm = ?," + 
		  		"durataFilm = ?," + 
		  		"genereFilm = ?," + 
		  		"tramaFilm = ?," + 
		  		"img = ?" + 
		  		"WHERE idFilm = ?";
		  System.out.println("Model: " + selectSQL);
		  try {
			  System.out.println("Model: 1");
		    connection = DriverManagerConnectionPool.getConnection();
		    System.out.println("Model: 2");
		    preparedStatement = connection.prepareStatement(selectSQL);
		    System.out.println("Model: 3");
		    preparedStatement.setInt(1, film.getIdFilm());
		    System.out.println("Model: 4");
		    preparedStatement.setString(2, film.getNomeFilm());
		    System.out.println("Model: 5");
		    preparedStatement.setString(3, film.getRegiaFilm());
		    System.out.println("Model: 6");
		    preparedStatement.setInt(4, film.getDurata());
		    System.out.println("Model: 7");
		    preparedStatement.setString(5, film.getGenere());
		    System.out.println("Model: 8");
		    preparedStatement.setString(6, film.getTrama());
		    System.out.println("Model: 9");
		    preparedStatement.setString(7, film.getImg());
		    System.out.println("Model: 10");
		    preparedStatement.setInt(8, film.getIdFilm());
		    System.out.println("Model: 11");

		    preparedStatement.executeUpdate();
		
		    connection.commit();
	  }
	  catch (SQLException se)
	  {
	    return false;
	  }
		  return true;
	}
}
