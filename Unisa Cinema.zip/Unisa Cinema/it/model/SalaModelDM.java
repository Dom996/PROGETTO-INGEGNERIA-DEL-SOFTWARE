package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import bean.PromozioneBean;
import bean.SalaBean;

public class SalaModelDM implements SalaModel{

	@Override
	public SalaBean doSave(SalaBean bean) throws SQLException {
		Connection connection = null;
        PreparedStatement preparedStatement = null;

        String insertSQL = "INSERT INTO sala (numeroPostiDisponibili)"
        					+ "VALUES (?)";
      try{
        connection = DriverManagerConnectionPool.getConnection();
        preparedStatement = connection.prepareStatement(insertSQL);
        preparedStatement.setInt(1,bean.getNumeriPostiDisponibili() );
        
        preparedStatement.executeUpdate();
        connection.commit();
        
            }
          finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}

	@Override
	public boolean doDelete(int idSala) throws SQLException {
		
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM sala WHERE idSala = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setInt(1, idSala);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public SalaBean doRetrieveByKey(int idSala) throws SQLException {
		
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  SalaBean bean = null;

		  String selectSQL = "SELECT * FROM sala WHERE idSala = ?"; 

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setInt(1, idSala);

		    ResultSet rs = preparedStatement.executeQuery();

		   if (rs.next()) {
		    	bean = new SalaBean();
		      bean.setIdSala(rs.getInt("idSala"));
		      bean.setNumeriPostiDisponibili(rs.getInt("numeroPostiDisponibili"));
		    } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return bean;
	}

	@Override
	public Collection<SalaBean> doRetrieveAll() throws SQLException {
		
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<SalaBean> sale = new LinkedList<SalaBean>();

		  String selectSQL = "SELECT * FROM sala";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		        SalaBean bean = new SalaBean();
		        bean.setIdSala(rs.getInt("idSala"));
		        bean.setNumeriPostiDisponibili(rs.getInt("numeroPostiDisponibili"));
		        sale.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return sale;
	}

}
