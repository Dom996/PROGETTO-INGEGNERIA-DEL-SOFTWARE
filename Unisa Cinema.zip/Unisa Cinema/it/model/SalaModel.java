package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.SalaBean;

public interface SalaModel {

	public SalaBean doSave(SalaBean bean) throws SQLException;
	
	public boolean doDelete(int idSala) throws SQLException;
	
	public SalaBean doRetrieveByKey(int idSala) throws SQLException;
	
	public Collection<SalaBean> doRetrieveAll() throws SQLException;
}
