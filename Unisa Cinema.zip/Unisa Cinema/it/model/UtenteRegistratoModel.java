package model;

import java.sql.SQLException;
import java.util.Collection;

import bean.UtenteRegistratoBean;

public interface UtenteRegistratoModel {

	public UtenteRegistratoBean doSave(UtenteRegistratoBean login) throws SQLException;
	
	public boolean doDelete(String email) throws SQLException;
	
	public UtenteRegistratoBean doRetrieveByKey(String email) throws SQLException;
	
	public Collection<UtenteRegistratoBean> doRetrieveAll() throws SQLException;
}
