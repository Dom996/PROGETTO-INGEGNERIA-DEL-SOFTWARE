package model;

import java.sql.SQLException;
import java.util.Collection;

import bean.PromozioneBean;

public interface PromozioneModel {

	public PromozioneBean doSave(PromozioneBean bean) throws SQLException;
	
	public boolean doDelete(int idPromozione) throws SQLException;
	
	public PromozioneBean doRetrieveByKey(int idPromozione) throws SQLException;
	
	public Collection<PromozioneBean> doRetrieveAll() throws SQLException;
}
