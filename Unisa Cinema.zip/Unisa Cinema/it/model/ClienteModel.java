package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.ClienteBean;

public interface ClienteModel {

	public ClienteBean doSave(ClienteBean bean) throws SQLException;
	
	public boolean doDelete(String email) throws SQLException;
	
	public ClienteBean doRetrieveByKey(String email) throws SQLException;
	
	public Collection<ClienteBean> doRetrieveAll() throws SQLException;
}
