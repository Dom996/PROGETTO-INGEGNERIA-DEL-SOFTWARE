package model;

import java.sql.SQLException;
import java.util.Collection;

import bean.OperatoreBean;

public interface OperatoreModel {

	public OperatoreBean doSave(OperatoreBean email) throws SQLException;
	
	public boolean doDelete(String email) throws SQLException;
	
	public OperatoreBean doRetrieveByKey(String email) throws SQLException;
	
	public Collection<OperatoreBean> doRetrieveAll() throws SQLException;
}
