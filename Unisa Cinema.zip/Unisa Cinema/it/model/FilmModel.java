package model;

import java.sql.SQLException;
import java.util.Collection;
import bean.FilmBean;

public interface FilmModel {
	
	public FilmBean doSave(FilmBean bean) throws SQLException;
	
	public boolean doDelete(int idFilm) throws SQLException;
	
	public FilmBean doRetrieveByKey(int idFilm) throws SQLException;
	
	public Collection<FilmBean> doRetrieveAll() throws SQLException;

}
