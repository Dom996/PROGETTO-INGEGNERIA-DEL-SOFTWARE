package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import bean.OperatoreBean;

public class OperatoreModelDM  implements OperatoreModel{

	@Override
	public OperatoreBean doSave(OperatoreBean bean) throws SQLException {
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        	sql = "INSERT INTO operatore (email,nome,cognome,et�,indirizzo)"
            + "VALUES (?,?,?,?,?)";
      
      try{
        connection = DriverManagerConnectionPool.getConnection();
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, bean.getEmail());
        preparedStatement.setString(2, bean.getNome());
        preparedStatement.setString(3, bean.getCognome());
        preparedStatement.setInt(4, bean.getEta());
        preparedStatement.setString(5, bean.getIndirizzo());
        
    	
        preparedStatement.executeUpdate();
        connection.commit();
              
            }
          finally {
            try{
              if(preparedStatement != null)
                preparedStatement.close();
            }finally {
              if(connection != null)
                connection.close();
            }
          }
	return bean;
	}

	public OperatoreBean update(OperatoreBean bean,String email2)throws SQLException{
		Connection connection = null;
        PreparedStatement preparedStatement = null;
        String sql;
        
        sql = "update operatore set email = ?, nome = ?, cognome = ?, et� = ?, indirizzo = ?  where email = ?";
        
        try{
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, bean.getEmail());
            preparedStatement.setString(2, bean.getNome());
            preparedStatement.setString(3, bean.getCognome());
            preparedStatement.setInt(4, bean.getEta());
            preparedStatement.setString(5, bean.getIndirizzo());
            preparedStatement.setString(6,email2);
      
            preparedStatement.executeUpdate();
            connection.commit();
            
                }
              finally {
                try{
                  if(preparedStatement != null)
                    preparedStatement.close();
                }finally {
                  if(connection != null)
                    connection.close();
                }
              }
    	return bean;
	}
	
	@Override
	public boolean doDelete(String email) throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  int result = 0;

		  String deleteSQL = "DELETE FROM operatore WHERE email = ?";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(deleteSQL);
		    preparedStatement.setString(1, email);

		    result = preparedStatement.executeUpdate();
		    connection.commit();
		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return (result != 0);
	}

	@Override
	public OperatoreBean doRetrieveByKey(String email) throws SQLException {
		Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  OperatoreBean bean = null;

		  String selectSQL = "SELECT * FROM operatore WHERE email = ?"; 

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);
		    preparedStatement.setString(1, email);

		    ResultSet rs = preparedStatement.executeQuery();

		    while (rs.next()) {
		    	bean = new OperatoreBean();
		    	bean.setEmail(rs.getString("email"));
		    	bean.setNome(rs.getString("nome"));
		    	bean.setCognome(rs.getString("cognome"));
		    	bean.setEta(rs.getInt("et�"));
		    	bean.setIndirizzo(rs.getString("indirizzo"));
		    } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return bean;
	}

	@Override
	public Collection<OperatoreBean> doRetrieveAll() throws SQLException {
		  Connection connection = null;
		  PreparedStatement preparedStatement = null;

		  Collection<OperatoreBean> coll = new LinkedList<OperatoreBean>();

		  String selectSQL = "SELECT * FROM operatore";

		  try {
		    connection = DriverManagerConnectionPool.getConnection();
		    preparedStatement = connection.prepareStatement(selectSQL);

		    ResultSet rs = preparedStatement.executeQuery();

		      
		      while (rs.next()) {
		    	  OperatoreBean bean = new OperatoreBean();
		        bean.setEmail(rs.getString("email"));
		        bean.setNome(rs.getString("nome"));
		        bean.setCognome(rs.getString("cognome"));
		        bean.setEta(rs.getInt("et�"));
		        bean.setIndirizzo(rs.getString("indirizzo"));
		        coll.add(bean);
		      } 

		  } finally {
		    try {
		      if (preparedStatement != null)
		        preparedStatement.close();
		    } finally {
		      if (connection != null)
		        connection.close();
		    }
		  }
		  return coll;
		}

	
}
