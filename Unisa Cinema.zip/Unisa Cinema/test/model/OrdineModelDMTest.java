package model;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.Iterator;

import org.junit.Test;

import bean.OrdineBean;

public class OrdineModelDMTest {

private OrdineModelDM model = new OrdineModelDM();
	
	@Test
	public void testSaveDeleteRetrieve() throws Exception {
		OrdineBean x = creaOrdine();
		model.doSave(x);
		Collection<OrdineBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 1);
		Iterator<OrdineBean> it = coll.iterator();
		OrdineBean obj = new OrdineBean();
		while (it.hasNext()) {
			obj = it.next(); 
		}
		int lastKey = obj.getNumeroOrdine();
		x = model.doRetrieveByKey(lastKey);
		assertNotNull(x);
		assertTrue(model.doDelete(lastKey));
		assertNull(model.doRetrieveByKey(lastKey));
	}

	private OrdineBean creaOrdine() {
		OrdineBean bean = new OrdineBean();
		bean.setEmailCliente("emailCliente");
		bean.setEmailOperatore("emailOperatore");
		bean.setNumeroBigliettiAcquistati(2);
		bean.setSceltaPagamento("sceltaPagamento");
		bean.setSceltaPoltrona("sceltaPoltrona");
		bean.setSceltaRitiro("sceltaRitiro");
		return bean;
	}
}
