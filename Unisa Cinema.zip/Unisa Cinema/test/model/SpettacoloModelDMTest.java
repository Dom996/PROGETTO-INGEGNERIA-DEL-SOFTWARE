package model;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.junit.Test;

import bean.SpettacoloBean;

public class SpettacoloModelDMTest {


private SpettacoloModelDM model = new SpettacoloModelDM();
	
	@Test
	public void testSaveDeleteRetrieve() throws Exception {
		SpettacoloBean x = creaSpettacolo();
		model.doSave(x);
		Collection<SpettacoloBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 1);
		Iterator<SpettacoloBean> it = coll.iterator();
		SpettacoloBean obj = new SpettacoloBean();
		while (it.hasNext()) {
			obj = it.next(); 
		}
		int lastKey = obj.getIdSpettacolo();
		x = model.doRetrieveByKey(lastKey);
		assertNotNull(x);
		assertTrue(model.doDelete(lastKey));
		assertNull(model.doRetrieveByKey(lastKey));
	}

	private SpettacoloBean creaSpettacolo() {
		SpettacoloBean x = new SpettacoloBean();
		x.setDataSpettacolo(new Date());
		x.setIdFilm(1);
		x.setIdSala(1);
		x.setNumeroPostiLiberi(20);
		x.setTreD("si");
		return x;
	}

}
