package model;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.junit.Test;

import bean.BigliettoBean;

public class BigliettoModelDMTest {

private BigliettoModelDM model = new BigliettoModelDM();
	
	@Test
	public void testSaveDeleteRetrieve() throws Exception {
		BigliettoBean x = creaBiglietto();
		model.doSave(x);
		Collection<BigliettoBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 1);
		Iterator<BigliettoBean> it = coll.iterator();
		BigliettoBean obj = new BigliettoBean();
		while (it.hasNext()) {
			obj = it.next(); 
		}
		int lastKey = obj.getCodiceBiglietto();
		x = model.doRetrieveByKey(lastKey);
		assertNotNull(x);
		assertTrue(model.doDelete(lastKey));
		assertNull(model.doRetrieveByKey(lastKey));
	}

	private BigliettoBean creaBiglietto() {
		BigliettoBean x = new BigliettoBean();
		x.setIdSpettacolo(1);
		x.setNumeroOrdine(1);
		x.setPrezzo(1);
		return x;
	}
}
