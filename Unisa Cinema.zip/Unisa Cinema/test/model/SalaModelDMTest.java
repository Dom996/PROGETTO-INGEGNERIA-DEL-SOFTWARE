package model;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.Iterator;

import org.junit.Test;

import bean.SalaBean;

public class SalaModelDMTest {


private SalaModelDM model = new SalaModelDM();
	
	@Test
	public void testSaveDeleteRetrieve() throws Exception {
		SalaBean x = creaSala();
		model.doSave(x);
		Collection<SalaBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 1);
		Iterator<SalaBean> it = coll.iterator();
		SalaBean obj = new SalaBean();
		while (it.hasNext()) {
			obj = it.next(); 
		}
		int lastKey = obj.getIdSala();
		x = model.doRetrieveByKey(lastKey);
		assertNotNull(x);
		assertTrue(model.doDelete(lastKey));
		assertNull(model.doRetrieveByKey(lastKey));
	}

	private SalaBean creaSala() {
		SalaBean x = new SalaBean();
		x.setNumeriPostiDisponibili(20);
		return x;
	}

}
