package model;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.junit.Test;

import bean.PromozioneBean;

public class PromozioneModelDMTest {

private PromozioneModelDM model = new PromozioneModelDM();
	
	@Test
	public void testSaveDeleteRetrieve() throws Exception {
		PromozioneBean x = creaPromozione();
		model.doSave(x);
		Collection<PromozioneBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 1);
		Iterator<PromozioneBean> it = coll.iterator();
		PromozioneBean obj = new PromozioneBean();
		while (it.hasNext()) {
			obj = it.next(); 
		}
		int lastKey = obj.getIdPromozione();
		x = model.doRetrieveByKey(lastKey);
		assertNotNull(x);
		assertTrue(model.doDelete(lastKey));
		assertNull(model.doRetrieveByKey(lastKey));
	}

	private PromozioneBean creaPromozione() {
		PromozioneBean bean = new PromozioneBean();
		bean.setNomePromozione("nomePromozione");
		bean.setDurataPromozione(new Date());
		return bean;
	}

}
