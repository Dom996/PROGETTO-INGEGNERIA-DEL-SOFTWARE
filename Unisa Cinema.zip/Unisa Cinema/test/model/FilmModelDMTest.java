package model;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.Iterator;

import org.junit.Test;

import bean.FilmBean;

public class FilmModelDMTest {

	private FilmModelDM model = new FilmModelDM();
	
	@Test
	public void testSaveDeleteRetrieve() throws Exception {
		FilmBean x = creaFilm();
		model.doSave(x);
		Collection<FilmBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 1);
		Iterator<FilmBean> it = coll.iterator();
		FilmBean obj = new FilmBean();
		while (it.hasNext()) {
			obj = it.next(); 
		}
		int lastKey = obj.getIdFilm();
		x = model.doRetrieveByKey(lastKey);
		assertNotNull(x);
		assertTrue(model.doDelete(lastKey));
		assertNull(model.doRetrieveByKey(lastKey));
	}

	private FilmBean creaFilm() {
		FilmBean bean = new FilmBean();
		bean.setNomeFilm("nomeFilm");
		bean.setGenere("genere");
		bean.setRegiaFilm("regiaFilm");
		bean.setDurata(20);
		bean.setTrama("trama");
		bean.setImg("img");
		return bean;
	}
}
