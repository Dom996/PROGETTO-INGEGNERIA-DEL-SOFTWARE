package model;

import static org.junit.Assert.*;

import java.util.Collection;
import java.util.Iterator;

import org.junit.Test;

import bean.PoltronaBean;

public class PoltronaModelDMTest {

	private PoltronaModelDM model = new PoltronaModelDM();
	
	@Test
	public void testSaveDeleteRetrieve() throws Exception {
		PoltronaBean x = creaPoltrona();
		model.doSave(x);
		Collection<PoltronaBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 1);
		Iterator<PoltronaBean> it = coll.iterator();
		PoltronaBean obj = new PoltronaBean();
		while (it.hasNext()) {
			obj = it.next(); 
		}
		int lastKey = obj.getIdPoltrona();
		x = model.doRetrieveByKey(lastKey);
		assertNotNull(x);
		assertTrue(model.doDelete(lastKey));
		assertNull(model.doRetrieveByKey(lastKey));
	}

	private PoltronaBean creaPoltrona() {
		PoltronaBean bean = new PoltronaBean();
		bean.setIdSala(1);
		bean.setNumeroFila(1);
		bean.setNumeroPosto(1);
		bean.setPostoLibero(true);
		return bean;
	}

}
