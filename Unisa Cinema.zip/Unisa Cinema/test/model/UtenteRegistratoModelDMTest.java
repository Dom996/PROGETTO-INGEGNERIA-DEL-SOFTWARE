package model;

import static org.junit.Assert.*;

import java.util.Collection;

import org.junit.Test;

import bean.UtenteRegistratoBean;

public class UtenteRegistratoModelDMTest {


private UtenteRegistratoModelDM model = new UtenteRegistratoModelDM();
	
	@Test
	public void testSaveDeleteRetrieveByKey() throws Exception {
		UtenteRegistratoBean x = creaUtenteRegistrato(email1);
		model.doSave(x);
		assertNotNull(model.doRetrieveByKey(email1));
		assertTrue(model.doDelete(email1));
		assertNull(model.doRetrieveByKey(email1));
	}

	@Test
	public void testUpdate() throws Exception {
		UtenteRegistratoBean x = creaUtenteRegistrato(email1);
		model.doSave(x);
		x.setEmail(email2);
		model.update(x, email1);
		assertNull(model.doRetrieveByKey(email1));
		assertNotNull(model.doRetrieveByKey(email2));
		model.doDelete(email2);
	}

	@Test
	public void testDoRetrieveAll() throws Exception {
		model.doSave(creaUtenteRegistrato(email1));
		model.doSave(creaUtenteRegistrato(email2));
		model.doSave(creaUtenteRegistrato(email3));
		Collection<UtenteRegistratoBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 3);
		model.doDelete(email1);
		model.doDelete(email2);
		model.doDelete(email3);
	}

	private UtenteRegistratoBean creaUtenteRegistrato(String key) {
		UtenteRegistratoBean x = new UtenteRegistratoBean();
		x.setEmail(key);
		x.setPassword("password");
		x.setTipologia("tipologia");
		return x;
	}
	
	private String email1 = "emailProvaTEST1";
	private String email2 = "emailProvaTEST2";
	private String email3 = "emailProvaTEST3";
	

}
