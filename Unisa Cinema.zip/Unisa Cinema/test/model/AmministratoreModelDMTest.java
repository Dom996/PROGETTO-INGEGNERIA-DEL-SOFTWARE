package model;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Collection;

import org.junit.Test;

import bean.AmministratoreBean;

public class AmministratoreModelDMTest {

	private AmministratoreModelDM model = new AmministratoreModelDM();
	
	@Test
	public void testSaveDeleteRetrieveByKey() throws Exception {
		AmministratoreBean x = creaAmministratore(email1);
		model.doSave(x);
		assertNotNull(model.doRetrieveByKey(email1));
		assertTrue(model.doDelete(email1));
		assertNull(model.doRetrieveByKey(email1));
	}

	@Test
	public void testUpdate() throws Exception {
		AmministratoreBean x = creaAmministratore(email1);
		model.doSave(x);
		x.setEmail(email2);
		model.update(x, email1);
		assertNull(model.doRetrieveByKey(email1));
		assertNotNull(model.doRetrieveByKey(email2));
		model.doDelete(email2);
	}

	@Test
	public void testDoRetrieveAll() throws Exception {
		model.doSave(creaAmministratore(email1));
		model.doSave(creaAmministratore(email2));
		model.doSave(creaAmministratore(email3));
		Collection<AmministratoreBean> coll = model.doRetrieveAll();
		assertNotNull(coll);
		assertTrue(coll.size() >= 3);
		model.doDelete(email1);
		model.doDelete(email2);
		model.doDelete(email3);
	}

	private AmministratoreBean creaAmministratore(String key) {
		AmministratoreBean x = new AmministratoreBean();
		x.setEmail(key);
		x.setCognome(cognome);
		x.setNome(nome);
		x.setEta(eta);
		x.setIndirizzo(indirizzo);
		return x;
	}
	
	private String email1 = "emailProvaTEST1";
	private String email2 = "emailProvaTEST2";
	private String email3 = "emailProvaTEST3";
	private String cognome = "cognomeProvaTEST";
	private String nome = "nomeProvaTEST";
	private String indirizzo = "indirizzoProvaTEST";
	private int eta = 20;
}
