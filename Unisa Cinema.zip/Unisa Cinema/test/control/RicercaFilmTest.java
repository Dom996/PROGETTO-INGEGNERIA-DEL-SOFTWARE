package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.cglib.proxy.Dispatcher;

public class RicercaFilmTest {
	
	private RicercaFilm servlet = new RicercaFilm();
	private HttpServletRequest request;
	private HttpServletResponse response;
	private RequestDispatcher dispatcher;
	

	@Before
	public void inizializzaMock() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
		dispatcher = mock(RequestDispatcher.class);
	}
	
	
	@Test
	public void testRicercaNull() throws Exception {
		when(request.getParameter("ricerca")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write("no");
	}
	

	
	public void testTipoNull() throws Exception {
		when(request.getParameter("tipo")).thenReturn(null);
		ServletContext servletContext = mock(ServletContext.class);
		//when(servletContext.getRequestDispatcher()).thenReturn("/Ricerca.jsp?tipo="+"sd"+"&campo="+"asd");		
		
	}

}
