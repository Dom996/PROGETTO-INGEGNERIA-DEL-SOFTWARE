package control;

import static org.junit.Assert.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;


public class AcquistoServletTest {

	private HttpServletRequest request;
	private HttpServletResponse response;
	private HttpSession session;
	private AcquistoServlet servlet = new AcquistoServlet();
	private PrintWriter writer;
	
	@Before
	public void setup() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
		session = mock(HttpSession.class);
		writer = mock(PrintWriter.class);
	}
	
	@Test
	public void qualcheParametroNullTest() throws IOException, ServletException {
		when(request.getParameter("idSpettacolo")).thenReturn("0");
		when(request.getParameter("pagamento")).thenReturn("carta");
		when(request.getParameter("ritiro")).thenReturn("stampa");
		when(request.getParameter("postiStr")).thenReturn(null);
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute("email")).thenReturn(null);
		when(response.getWriter()).thenReturn(writer);
		servlet.doPost(request, response);
		verify(writer).write("L'operazione richiesta non e' valida.");
	}

	@Test
	public void okTest() throws IOException, ServletException {
		when(request.getParameter("idSpettacolo")).thenReturn("0");
		when(request.getParameter("pagamento")).thenReturn("carta");
		when(request.getParameter("ritiro")).thenReturn("stampa");
		when(request.getParameter("postiStr")).thenReturn("1-2-3-");
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute("email")).thenReturn(null);
		when(response.getWriter()).thenReturn(writer);
		servlet.doPost(request, response);
		verify(response).getWriter();
	}
	
	@After
	public void teardown() {
		request = null;
		response = null;
		session = null;
		writer = null;
	}
}
