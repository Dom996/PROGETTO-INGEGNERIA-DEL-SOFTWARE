package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;

import bean.FilmBean;
import model.FilmModelDM;


public class AggiungiFilmTest {
	
	private AggiungiFilm servlet = new AggiungiFilm();
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	@Before
	public void inizializzaMock() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
	}
	
	@Test
	public void testAction() throws Exception {
		when(request.getParameter("action")).thenReturn(null);
		PrintWriter p = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(p);
		servlet.doPost(request, response);
		verify(p).write(BADREQUEST_MESS+"1");	
	}

	
	@Test
	public void testImg() throws Exception {
	when(request.getParameter("action")).thenReturn("action");
	when(request.getParameter("img")).thenReturn(null);
	PrintWriter MyWriter = mock(PrintWriter.class);
	when(response.getWriter()).thenReturn(MyWriter);
	servlet.doPost(request, response);	
	verify(MyWriter).write(BADREQUEST_MESS+"2");
	}
	
	@Test
	public void testGenere() throws Exception{
		FilmModelDM f = new FilmModelDM();
		FilmBean film = new FilmBean();
		film.setGenere("e");
		f.doSave(film);
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("str");
		when(request.getParameter("genere")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(MyWriter).write(BADREQUEST_MESS+"3");
		
	}
	
	@Test
	public void testDurata() throws Exception{
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("str");
		when(request.getParameter("genere")).thenReturn("ciao");
		when(request.getParameter("durata")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(MyWriter).write(BADREQUEST_MESS+"4");
		
	}
	
	
	@Test
	public void testRegia() throws Exception{
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("str");
		when(request.getParameter("genere")).thenReturn("ciao");
		when(request.getParameter("durata")).thenReturn("2");
		when(request.getParameter("regia")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(MyWriter).write(BADREQUEST_MESS+"5");
		
	}
	
	
	@Test
	public void testTrama() throws Exception{
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("str");
		when(request.getParameter("genere")).thenReturn("ciao");
		when(request.getParameter("durata")).thenReturn("2");
		when(request.getParameter("regia")).thenReturn("asd");
		when(request.getParameter("trama")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(MyWriter).write(BADREQUEST_MESS+"6");
		
	}
	
	
	@Test
	public void testNome() throws Exception{
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("str");
		when(request.getParameter("genere")).thenReturn("ciao");
		when(request.getParameter("durata")).thenReturn("2");
		when(request.getParameter("regia")).thenReturn("asd");
		when(request.getParameter("trama")).thenReturn("ertert");
		when(request.getParameter("nome")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(MyWriter).write(BADREQUEST_MESS+"7");
	}
	
	@Test
	public void testActionAggiungiFilm() throws Exception{
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("stringaaaaaasdasdasdasdasdasda");
		when(request.getParameter("genere")).thenReturn("ciao");
		when(request.getParameter("durata")).thenReturn("2");
		when(request.getParameter("regia")).thenReturn("asd");
		when(request.getParameter("trama")).thenReturn("ertert");
		when(request.getParameter("nome")).thenReturn("cai");
		when(request.getParameter("action")).thenReturn("aggiungiFilm");
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(response).getWriter();
	}
	
	
	@Test
	public void testActionCancellaFilm() throws Exception{
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("stringaaaaaasdasdasdasdasdasda");
		when(request.getParameter("genere")).thenReturn("ciao");
		when(request.getParameter("durata")).thenReturn("2");
		when(request.getParameter("regia")).thenReturn("asd");
		when(request.getParameter("trama")).thenReturn("ertert");
		when(request.getParameter("nome")).thenReturn("cai");
		when(request.getParameter("action")).thenReturn("cancellaFilm");
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		when(request.getParameter("id")).thenReturn("3");	
		servlet.doPost(request, response);
		verify(MyWriter).write("no");
	}
	

	
	@Test
	public void testSuccessUpSi() throws Exception{
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("img")).thenReturn("strinjhbbnkkn");
		when(request.getParameter("genere")).thenReturn("ciao");
		when(request.getParameter("durata")).thenReturn("2");
		when(request.getParameter("regia")).thenReturn("asd");
		when(request.getParameter("trama")).thenReturn("ertert");
		when(request.getParameter("nome")).thenReturn("cai");
		when(request.getParameter("id")).thenReturn("3");
		when(request.getParameter("action")).thenReturn("modificaFilm");
		when(request.getParameter("successUp")).thenReturn("true");
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(MyWriter).write("ok");
	}
	

	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";
}
