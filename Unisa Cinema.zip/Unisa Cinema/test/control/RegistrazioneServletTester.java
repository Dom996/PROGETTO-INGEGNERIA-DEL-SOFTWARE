package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;

import bean.ClienteBean;
import bean.UtenteRegistratoBean;
import model.ClienteModelDM;
import model.UtenteRegistratoModelDM;

public class RegistrazioneServletTester {
	  
		private RegistrazioneServlet servlet = new RegistrazioneServlet();
		private HttpServletRequest request;
		private HttpServletResponse response;
		private HttpSession session;
		
		@Before
		public void inizializzaMock() {
			request = mock(HttpServletRequest.class);
			response = mock(HttpServletResponse.class);
			session = mock(HttpSession.class);
		}

	@Test
	public void testAction() throws Exception {
		when(request.getParameter("action")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	@Test
	public void testModificaProfilo() throws Exception {
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	

	@Test
	public void testNome() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	
	@Test
	public void testCognome() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn("ciao");
		when(request.getParameter("cognome")).thenReturn(null);
		
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	@Test
	public void testEtas() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn("ciao");
		when(request.getParameter("cognome")).thenReturn("wdfwef");
		when(request.getParameter("etaS")).thenReturn(null);
		
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	@Test
	public void testIndirizzo() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("600");
		when(request.getParameter("indirizzo")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	@Test
	public void testEmail() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	@Test
	public void testEmail2() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn("carloDiGiamp@gmail.com");
		when(request.getParameter("emaildue")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	@Test
	public void testPassword() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn("carloDiGiamp@gmail.com");
		when(request.getParameter("emaildue")).thenReturn("carloDiGiamp2@gmail.com");
		when(request.getParameter("password")).thenReturn(null);
	
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	@Test
	public void testClienteNull() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("ModificaProfilo");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn("carloDiGiamp@gmail.com");
		when(request.getParameter("emaildue")).thenReturn("carloDiGiamp2@gmail.com");
		when(request.getParameter("password")).thenReturn("sdfsdfsdfgsdf");
		when(request.getParameter("cliente")).thenReturn("cliente");
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		when(request.getSession()).thenReturn(session);
		servlet.doPost(request, response);	
		verify(response).getWriter();
	}
	
	

	@Test
	public void testRegistrazione() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn("carloDiGiamp@gmail.com");
		when(request.getParameter("emaildue")).thenReturn("carloDiGiamp2@gmail.com");
		when(request.getParameter("password")).thenReturn("sdfsdfsdfgsdf");
		when(request.getParameter("cliente")).thenReturn("cliente");
		when(request.getSession()).thenReturn(session);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	public void testNomeReg() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	@Test
	public void testCognomeReg() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn("ciao");
		when(request.getParameter("cognome")).thenReturn(null);
		
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	@Test
	public void testEtasRegistrazione() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn("ciao");
		when(request.getParameter("cognome")).thenReturn("wdfwef");
		when(request.getParameter("etaS")).thenReturn(null);
		
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	@Test
	public void testIndirizzoReg() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("600");
		when(request.getParameter("indirizzo")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	@Test
	public void testEmailReg() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	@Test
	public void testEmail2Reg() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn("carloDiGiamp@gmail.com");
		when(request.getParameter("emaildue")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	@Test
	public void testPasswordReg() throws Exception {
		when(request.getParameter("action")).thenReturn("action");
		when(request.getParameter("action")).thenReturn("Registrazione");
		when(request.getParameter("nome")).thenReturn("Carlo");
		when(request.getParameter("cognome")).thenReturn("Di Giampaolo");
		when(request.getParameter("eta")).thenReturn("60");
		when(request.getParameter("indirizzo")).thenReturn("Giuseppe Pellegrino");
		when(request.getParameter("email")).thenReturn("carloDiGiamp@gmail.com");
		when(request.getParameter("emaildue")).thenReturn("carloDiGiamp2@gmail.com");
		when(request.getParameter("password")).thenReturn(null);
	
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	}
	
	
	
	
	
	
	 /** messaggio di errore inviato in caso di bad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";
}
