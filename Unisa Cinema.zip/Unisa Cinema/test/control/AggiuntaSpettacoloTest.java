package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;

public class AggiuntaSpettacoloTest {


	
	
	private AggiuntaSpettacolo servlet = new AggiuntaSpettacolo();
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	@Before
	public void inizializzaMock() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
	}
	
	@Test
	public void testDataSpettacolo() throws Exception {
		when(request.getParameter("data")).thenReturn(null);
		PrintWriter p = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(p);
		servlet.doPost(request, response);
		verify(p).write(BADREQUEST_MESS);	
	}
	
	@Test
	public void testTreD() throws Exception {
		when(request.getParameter("data")).thenReturn("2018-01-01");
		
		when(request.getParameter("treD")).thenReturn(null);
		PrintWriter p = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(p);
		servlet.doPost(request, response);
		verify(p).write(BADREQUEST_MESS);	
	}
	
	@Test
	public void testNumeroPostiLiberi() throws Exception {
when(request.getParameter("data")).thenReturn("2018-01-01");
		
		when(request.getParameter("treD")).thenReturn("si");
		
		when(request.getParameter("numeroPostiLiberi")).thenReturn(null);
		PrintWriter p = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(p);
		servlet.doPost(request, response);
		verify(p).write(BADREQUEST_MESS);	
	}
	
	@Test
	public void testCollNull() throws Exception {
when(request.getParameter("data")).thenReturn("2018-01-01");
		
		when(request.getParameter("treD")).thenReturn("si");
		
		when(request.getParameter("posti")).thenReturn("2");
		
		PrintWriter p = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(p);
		HttpSession session = mock(HttpSession.class);
		when(request.getSession()).thenReturn(session);
		servlet.doPost(request, response);
		verify(response).getWriter();	
	}
	
	
	

	 /** messaggio di errore inviato in caso di bad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";
}
