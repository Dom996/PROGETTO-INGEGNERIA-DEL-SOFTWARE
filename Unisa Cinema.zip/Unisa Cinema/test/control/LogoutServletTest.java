package control;

import static org.junit.Assert.*;

import org.junit.Test;

public class LogoutServletTest {

	@Test
	public void test() {
	

}
}
