package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;

import bean.UtenteRegistratoBean;
import model.UtenteRegistratoModelDM;

public class LoginClienteTest {

	private LoginCliente servlet = new LoginCliente();
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	@Before
	public void inizializzaMock() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
	}
	
	
	@Test
	public void testUtenteInesistente() throws Exception {
		when(request.getParameter("utente")).thenReturn(null);
		//when(request.getParameter("email")).thenReturn("emailCheNonEsiste@email.com");
		//when(request.getParameter("password")).thenReturn("passwordCiao");
		servlet.doPost(request, response);
		verify(response).sendRedirect("home.jsp");
		}

	@Test
	public void testUtenteTipo() throws Exception {
		
	}
}
