package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;

public class EliminaFilmTest {
	private EliminaFilmServlet servlet = new EliminaFilmServlet();
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	@Before
	public void inizializzaMock() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
	}
	
	@Test
	public void testDataSpettacolo() throws Exception {
		when(request.getParameter("action")).thenReturn("delete");
		PrintWriter p = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(p);
		when(request.getParameter("idFilm")).thenReturn("0");
		
		servlet.doGet(request, response);
		verify(response).getWriter();	
	}
	
}
