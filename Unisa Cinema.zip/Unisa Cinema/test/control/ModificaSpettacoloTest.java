package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;

import bean.SpettacoloBean;
import model.SpettacoloModelDM;

public class ModificaSpettacoloTest {
	
	/** messaggio di errore inviato in caso di bad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  
	private ModificaSpettacoloServlet servlet = new ModificaSpettacoloServlet();
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	@Before
	public void inizializzaMock() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
	}
	
	@Test
	public void testDataSpettacolo() throws Exception {
		when(request.getParameter("dataSpettacolo")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	
	}
	
	@Test
	public void testTreD() throws Exception {
		when(request.getParameter("treD")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	
	}
	
	@Test
	public void testNumeroPostiLiberi() throws Exception {
		when(request.getParameter("numeroPostiLiberi")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	
	}
	
	@Test
	public void testColl() throws Exception {
		when(request.getParameter("coll")).thenReturn(null);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);	
		verify(MyWriter).write(BADREQUEST_MESS);
	
	}
	
	
	public void testSpettacolo() throws Exception {
		SpettacoloModelDM modelSpettacolo = new SpettacoloModelDM();
		SpettacoloBean spettacolo = new SpettacoloBean();
		spettacolo.setIdSpettacolo(2);
		spettacolo.setIdSala(3);
		spettacolo.setDataSpettacolo(new Date());
		spettacolo.setIdFilm(4);
		spettacolo.setNumeroPostiLiberi(300);
		spettacolo.setTreD("0");
		modelSpettacolo.doSave(spettacolo);
		
		Collection<SpettacoloBean> coll = modelSpettacolo.doRetrieveAll();
		
	   // when(request.getParameter("spettacolo")).thenReturn(coll);
		PrintWriter MyWriter = mock(PrintWriter.class);
		when(response.getWriter()).thenReturn(MyWriter);
		servlet.doPost(request, response);
		verify(MyWriter).write("ok");
		
	
	}
	

}
