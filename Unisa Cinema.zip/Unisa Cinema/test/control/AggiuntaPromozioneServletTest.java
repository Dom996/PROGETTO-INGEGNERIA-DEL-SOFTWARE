package control;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import bean.PromozioneBean;
import model.PromozioneModelDM;

public class AggiuntaPromozioneServletTest {



	private AggiuntaPromozioneServlet servlet = new AggiuntaPromozioneServlet();
	private HttpServletRequest request;
	private HttpServletResponse response;
	private PrintWriter writer;

	@Before
	public void inizializzaMock() {
		request = mock(HttpServletRequest.class);
		response = mock(HttpServletResponse.class);
		writer = mock(PrintWriter.class);
	}


	@Test
	public void testNomePromozione() throws Exception {
		when(request.getParameter("nomePromozione")).thenReturn(null);
		when(response.getWriter()).thenReturn(writer);
		servlet.doPost(request, response);
		verify(writer).write(BADREQUEST_MESS);	
	}



	@Test
	public void testColl() throws Exception {
		when(request.getParameter("nome")).thenReturn("SinuCazz");
		when(request.getParameter("durata")).thenReturn("2017-02-18");
		
		when(response.getWriter()).thenReturn(writer);
		servlet.doPost(request, response);
		verify(response).getWriter();	
	}

	@Test
	public void test2() throws Exception {
		when(request.getParameter("nome")).thenReturn("SinuCazz");
		when(request.getParameter("durata")).thenReturn("nonData");
		when(response.getWriter()).thenReturn(writer);
		servlet.doPost(request, response);
		verify(response).getWriter();	
	}
	
	
	@After
	public void teardown() {
		request = null;
		response = null;
		writer = null;
	}
	
	
	

	/** messaggio di errore inviato in caad request. **/
	  private static final String BADREQUEST_MESS = "L'operazione richiesta non e' valida.";

	  /** messaggio restituito in caso di successo dell'operazione. **/
	  private static final String SUCCESS_MESS = "L'operazione e' avvenuta correttamente.";
}
